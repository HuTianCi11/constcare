<script>
	export default {
		globalData: {
			identity:0, // 1 总包 2 分包
			subId:null,
			minId:null,
			pageIndex:null
		},
		onLaunch: function() {
			console.log('App Launch')
			uni.hideTabBar()
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "uview-ui/index.scss";
	@import '/static/css/uni.css';
    uni-checkbox-group{ width: 100% !important; }
    uni-checkbox-group uni-label{ width: 33% !important; display: inline-flex; margin-bottom: 20rpx; }
    
    /*checkbox 选项框大小  */
    uni-checkbox .uni-checkbox-input{
    	width: 30rpx !important;
    	height: 30rpx !important;
    }
    
    /*checkbox选中后样式  */
    uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked{
    	background: #1890FF;
    	border-color:#1890FF;
    }
    
    /*checkbox选中后图标样式  */
    uni-checkbox .uni-checkbox-input.uni-checkbox-input-checked::before{
        width: 40rpx;
        height: 40rpx;  
    	line-height: 40rpx;
    	text-align: center;
    	font-size: 16rpx;
    	color: #fff;
    	background: transparent;
    	transform: translate(-70%, -50%) scale(1);
    	-webkit-transform: translate(-70%, -50%) scale(1);
		margin-left:8rpx;
    }


</style>
