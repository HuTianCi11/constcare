<template>
	<!-- <view class="">
		<view class="title-group">
			<view class="select-bar">
				<view :class="choice==1?'title':'ttl'" @click="switchBar(1)">{{identity==1?'Min':'Sub'}} Info</view>
				<view  style="width: 35rpx;"></view>
				<view :class="choice==2?'title':'ttl'"  @click="switchBar(2)">User</view>
			</view>
			<view class="out" @click="out">
				<image class="close-icon" src="/static/icon/signout@3x.png" mode="widthFix"></image>
				<view class="out-text">sign out</view>
			</view>
		</view>
		<view class="content" :class="choice==1?'choice-bg1':'choice-bg2'">
		<block class="" v-if="choice==1">
			<image :src="content.logoPath" @click="seeImg(content.logoPath)" mode="widthFix" class="avatar"></image>
			<view class="title-name">
				Construction Site Name：<text class="describe">{{content.name}}</text>
			</view>
			<view class="title-name">
				Detailed Address：<text class="describe">{{content.address}}</text>
			</view>
			<view class="title-name">
				Contact Person:<text class="describe">{{content.contactPerson}}</text>
			</view>
			<view class="title-name">
				Email:<text class="describe">{{content.email}}</text>
			</view>
			<view class="title-name">
				Mobile Phone Number:<text class="describe">{{content.mobilePhone}}</text>
			</view>
		</block>
		<block v-if="choice==2" >
			<view class="content-title">
				{{userInfo.nicename}}
			</view>
			<view class="title-name">
				Email:：<text class="describe">{{userInfo.email}}</text>
			</view>
			<view class="title-name">
				Mobile Phone Number:<text class="describe">{{userInfo.mobilePhone}}</text>
			</view>
			<image @click="seeImg(userInfo.signPath)" :src="userInfo.signPath" mode="widthFix" class="avatar"></image>
		</block>
		</view>
	</view> -->
	
	<view class="pagebg">
		<view class="bgImg-item ">
			<image :src="bgImg" mode="widthFix" class="bgImg"></image>
			<view class="title-group">
				<view class="select-bar">
					<view :class="choice==1?'title':'ttl'" @click="switchBar(1)">{{identity==1?'Min':'Sub'}} Info</view>
					<view  style="width: 35rpx;"></view>
					<view :class="choice==2?'title':'ttl'"  @click="switchBar(2)">User</view>
				</view>
				<view class="out" @click="out">
					<image class="close-icon" src="/static/icon/signout@3x.png" mode="widthFix"></image>
					<view class="out-text">Login Out</view>
				</view>
			</view>
			<block class="" v-if="choice==1">
				<view class="block-pd ">
					<image :src="content.logoPath" @click="seeImg(content.logoPath)" mode="widthFix" class="avatar"></image>
					<view class="BGwhite">
						<view class="newItem">
							<image src="../static/icon/csn@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Company Name：</view>
								<view class="describe" v-if="content.name!=null">{{content.name}}</view>
							</view>
						</view>
						<view class="newItem">
							<image src="../static/icon/da@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Detailed Address：</view>
								<view class="describe" v-if="content.address!=null">{{content.address}}</view>
							</view>
						</view>
						<view class="newItem">
							<image src="../static/icon/cp@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Contact Person:</view>
								<view class="describe" v-if="content.contactPerson!=null">{{content.contactPerson}}</view>
							</view>
						</view>
						<view class="newItem">
							<image src="../static/icon/email@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Email:</view>
								<view class="describe" >{{content.email}}</view>
							</view>
						</view>
						<view class="newItem">
							<image src="../static/icon/mpn@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Mobile Phone Number:</view>
								<view class="describe" v-if="content.mobilePhone!=null">{{content.mobilePhone}}</view>
							</view>
						</view>
					</view>
				</view>
			</block>
			
			<block class="" v-else>
				<view class="block-pd " >
					<image :src="userInfo.signPath" @click="seeImg(userInfo.signPath)" mode="widthFix" class="avatar"></image>
					<view class="BGwhite" style="padding-bottom: 300rpx;">
						<view class="content-title">
							{{userInfo.nicename}}
						</view>
						<view class="newItem">
							<image src="../static/icon/email@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Email:</view>
								<view class="describe" >{{userInfo.email}}</view>
							</view>
						</view>
						<view class="newItem">
							<image src="../static/icon/mpn@3x.png" mode="widthFix" class="icons"></image>
							<view class="title-name-item">
								<view class="title-name" >Mobile Phone Number:</view>
								<view class="describe" >{{userInfo.mobilePhone}}</view>
							</view>
						</view>
					</view>
				</view>
			</block>

		</view>
		
	</view>
	
	
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				choice:1,
				identity:"",
				content:"",
				userInfo:"",
				userIds:"",
				bgImg:"../../static/icon/bg@3x.png"
			}
		},
		mounted(){
			this.choice=1
			this.userIds =  uni.getStorageSync('loginData').id;
			console.log(this.userIds,"this.userIds")
			this.identity = app.globalData.identity
			this.echo()
		},
		methods: {
			seeImg(url){
				console.log(url)
				uni.previewImage({
					current:0, 
					urls:[url] 
				})
			},
			switchBar(num){
				console.log(num)
				this.choice=num
				if(num==1){
					this.bgImg="../../static/icon/bg@3x.png"
					this.echo()
				}else{
					this.user()
					this.bgImg="../../static/icon/bg01@3x.png"
				}
				
			},
			async user(){
				var that= this
					const res = await this.$myReuqest({
						url:'user/userInfo/',
						method:"POST",
						data:{
							userIds:this.userIds
						},
						// hidden:true,
						header:{'content-type': 'application/x-www-form-urlencoded'},
					})
					console.log(res)
					if(res.code==200){
						that.userInfo = res.data
					}else{
						uni.showToast({
							title:res.msg,
							icon:'none'
						})
					}
			},
			async echo(){
				var that= this
					const res = await this.$myReuqest({
						url:'sub/echoPro/',
						method:"GET",
						data:{
							userId:this.userIds
						},
						// hidden:true,
						header:{'content-type': 'application/x-www-form-urlencoded'},
					})
					console.log(res)
					if(res.code==200){
						that.content = res.data
					}else{
						uni.showToast({
							title:res.msg,
							icon:'none'
						})
					}
			},
			out(){
				try {
				    uni.removeStorageSync('loginData');
					console.log("清楚成功")
				} catch (e) {
				    console.log("清楚缓存失败",e)
				}
				uni.redirectTo({
					url:'../login/login'
				})
			}

		},
	}
</script>

	
<style>
	.title-name-item{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.newItem{
		display: flex;
		align-items: center;
		border-bottom: 1rpx solid #F2F3F8;
	}
	.icons{
		width: 24rpx;
		height: auto;
		margin-right: 25rpx;
	}
	.pagebg{
		background-color: rgb(243,248,254);
		height: 100vh;
	}
	.BGwhite{
		background: #FFFFFF;
		padding:6rpx 30rpx  120rpx 30rpx;
		margin-top: 60rpx;
	}
	.block-pd{
		padding: 0 30rpx;
	}
	.bgImg-item{
		width: 100%;
		position: fixed;
		top: 0;
		left: 0;
	}
	.bgImg{
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: auto;
		z-index: -1;
	}

	.title-group{
		display: flex;
		align-items: center;
		padding: 110rpx 30rpx 48rpx 30rpx ;
		justify-content: space-between;
/* 		background-color: #FFFFFF; */
	}
	.select-bar{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.title{
		font-size: 40rpx;
		font-weight: 500;
		color: #FFFFFF;
	}
	.ttl{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		margin-top: 2rpx;
	}
	.tip{
		margin-top: 8rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-left: 38rpx;
	}
	.close-icon{
		width: 24rpx;
		height: auto;
	}
	.out{
		width: 155rpx;
		height: 50rpx;
		background: #FA5237;
		border-radius: 25rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.out-text{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
		margin-left: 7rpx;
		margin-bottom: 6rpx;
	}
	.title-name{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin: 50rpx 0 ;
	}
	.describe{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 30rpx;
	}
	.content{
		background-color: #FFFFFF;
		margin-top: 20rpx;
		padding: 40rpx 30rpx;
	}
	.avatar{
		width: 163rpx;
		height: auto;
		border-radius: 5rpx;
	}
	.content-title{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
		margin-top: 42rpx;
		padding-bottom: 60rpx;
		border-bottom: 1rpx solid #F2F3F8;
	}
	.choice-bg1{
		padding-bottom: 67rpx;
		margin-bottom: 20rpx;
	}
	.choice-bg2{
		height: 74vh;
		margin-bottom: 20rpx;
	}
</style>
