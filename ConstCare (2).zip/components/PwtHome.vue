<template>
	<view class="">
		<view class="title-group">
			<view :class="bar==1?'title':'tip'" @click="switchBar(1)">Subcontractor</view>
			<view  style="width: 38rpx;"></view>
			<view :class="bar==1?'tip':'title'" @click="switchBar(2)">WAH</view>
		</view>
		<view class="choice">
			<view class="choice-btn">
				<view :class="item.click==1?'choice-sel':'choice-no'" @click="choice(index)" v-for="(item,index) in titles" :style="{borderLeft:index>0?'1px solid #DEDFEC':''}">{{item.title}}</view>
			</view>
	<!-- 		<view class="create-item" @click="create" v-if="identity==2&&roleId==3">
				<image src="../static/icon/create@3x.png"  class="creat-icon"></image>
				<view class="create-text">Create</view>
			</view> -->
		</view>
		<view class="groups" v-for="(items,indexs) in list" @click="detail(items)">
			<view class="project" style="margin-bottom: 30rpx;">
				<view class="project-Name">{{items.projectNo}}</view>
				<view class="whp">{{items.sno}}</view>
			</view>
			<view class="project" style="margin-bottom: 20rpx;">
				<view class="project-date">{{items.validityStartDate}} to {{items.validityEndDate}}</view>
				<view class="state">S/NO</view>
			</view>
			<view class="project">
				<view class="project-hour">{{items.validityStartHr}} hr  to {{items.validityEndHr}} hr</view>
				<view class="process-group"  >
					<view class="process" :class="'color'+items.p1SignStatus" ></view>
					<view class="process" :class="'color'+items.p2SignStatus" ></view>
					<view class="process" :class="'color'+items.p3SignStatus" ></view>
					<view v-if="items.p4ApplyType">
						<view class="process" :class="'color'+items.p4SignStatus" ></view>
					</view>
					<view  v-else>
						<view class="process colorgray" ></view>
					</view>
					
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				identity:"",
				roleId:"",
				colors:[
					{type:1},
					{type:2},
					{type:3},
					{type:4},
				],
				titles:[
					{"title":"All","click":1},
					{"title":"Pending","click":0},
					{"title":"Processed","click":0},
				],
				bar:1,
				current:1,
				userid:"",
				workType:true,
				type:null,
				list:[]
			}
		},
		mounted(){
			this.identity = app.globalData.identity
			var loginData = uni.getStorageSync('loginData')
			this.roleId =loginData.roleId
			this.userid = loginData.id
			this.queryPtw()
			uni.$on('test',(name,type)=>{
				console.log('监听pwt',name,type);
				if(name=='pwt'){
					if(type=='up'){
						this.current=1
						// this.list=[]
						this.queryPtw(0,true,type)
					}else{
						if(name=='pwt'&& this.list.length%10==0){
							this.queryPtw(1)
						}
					}
				}
				
			})
		},
		methods: {
			async queryPtw(current=0,hidden=false,type=''){
				console.log(current,'current')
				this.current = this.current+current
				var that = this
				const res = await this.$myReuqest({
					url:'ptw/queryPtw/',
					method:"POST",
					data:{
					  "current": this.current,
					  "size": 10,
					  "type": this.type,
					  "userId": this.userid,
					  "workType":this.workType
					},
					hidden:hidden
				})
				// let test = {
				// 	  "current": this.current,
				// 	  "size": 10,
				// 	  "type": this.type,
				// 	  "userId": this.userid,
				// 	  "workType":this.workType
				// 	}
				// console.log(test)
				console.log(res)
				if(res.code==200){
					if(type=='up'){
						that.list=[]
					}
					var records = res.data.records
					for (let i=0;i<records.length;i++) {
						let start = records[i].validityStartHr.split(":")
						let end = records[i].validityEndHr.split(":")
						records[i].validityStartHr = start[0]+":"+start[1]
						records[i].validityEndHr = end[0]+":"+end[1]
						that.list.push(records[i])
					}
					// that.list = records
					
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			create(){
				uni.navigateTo({
					url:"/pages/pwt/pwt-create"
				})
			},
			//3个标签切换
			choice(index){
				this.list=[]
				this.current = 1
				this.titles[index].click=1
				for(let i=0;i<this.titles.length;i++){
					if(i!=index){
						this.titles[i].click=0
					}
				}
				console.log(index)
				if(index==0){
					this.type=null
				}else if(index==1){
					this.type=true
				}else{
					this.type=false
				}
				console.log(this.type)
				this.queryPtw()
			},
			//顶部切换
			switchBar(e){
				this.bar=e
				this.list = []
				this.current = 1
				if(e==1){
					this.workType=true
				}else{
					this.workType=false
				}
				this.queryPtw()
			},
			detail(e){
				uni.navigateTo({
					// url:"/pages/pwt/pwt-detail?data="+JSON.stringify(e)
					url:"/pages/pwt/pwt-detail?data="+encodeURIComponent(JSON.stringify(e))
				})
			}
		},
	}
</script>

<style>
	.create-item{
		width: 140rpx;
		height: 50rpx;
		background: #14D6AF;
		border-radius: 24rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.creat-icon{
		width: 21rpx;
		height: 21rpx;
	}
	.create-text{
		margin-left: 6rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.title-group{
		display: flex;
		align-items: center;
		padding: 110rpx 30rpx 70rpx 30rpx;
	}
	.title{
		font-size: 36rpx;
		font-weight: 500;
		color: #232323;
	}
	.tip{
		margin-top: 8rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
/* 		margin-left: 38rpx; */
	}
	.choice-btn{
		display: flex;
		align-items: center;
		border: 1px solid #DEDFEC;
	}
	.choice{
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 25rpx;
		padding:0 30rpx;
	}
	.choice-sel{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		height: 50rpx;
		background: #1890FF;
		display: flex;
		justify-content: center;
		align-items: center;
		padding: 0 30rpx;
	/* 	border: 1px solid #DEDFEC; */
	}
	.choice-no{
		display: flex;
		padding: 0 30rpx;
		justify-content: center;
		align-items: center;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		height: 50rpx;
		background: #FFFFFF;
	/* 	border: 1px solid #DEDFEC; */
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.groups{
		background: #F3F8FE;
		padding: 40rpx 30rpx 50rpx 30rpx;
		margin-bottom: 30rpx;
	}
	.project{
		justify-content: space-between;
		align-items: center;
		display: flex;
	}
	.project-Name{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.project-hour{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.whp{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.project-date{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.state{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.process{
		width: 18rpx;
		height: 18rpx;
		border-radius: 50%;
		margin-left: 13rpx;
	}
	.colortrue{
		background-color: #22DF9B;
	}
	.colornull{
		background-color: #2FD2EA;
	}
	.colorfalse{
		background-color: #F34635;
	}
	.colorgray{
		background-color: #9095B8;
	}
	
	

	.process-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
</style>
