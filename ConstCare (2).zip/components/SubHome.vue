<template>
	<view class="">
		<view class="title-group">
			<view class="title">Subcontractor</view>
			<image src="/static/icon/addto@3x.png" @click="creat" class="add-icon"></image>
		</view>
		<view class="groups" v-for="(item,index) in list" @click="detail(index)">
			<view class="company">
				<view class="level">{{item.companyCategory}}</view>
				<view class="company-Name">{{item.name}}</view>
			</view>
			<view class="items">
				<view class="orders">
					<text class="orderid">{{item.uenNo}}</text><text class="order-type">UEN NO</text>
				</view>
				<view class="">
					<text class="number">{{item.taskCount}}</text><text class="words" >Task</text><text class="number" style="margin-left: 22rpx;">{{item.works}}</text><text class="words">Woker</text>
				</view>
			</view>
			
		</view>
	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return { 
				current:1,
				list:[],
			}
		},
		mounted(){
			console.log('总包商id',app.globalData.minId)
			this.querySub()
			uni.$on('test',(name,type)=>{
					console.log('监听sub',name,type);
					if(name=='sub'){
						if(type=='up'){
							this.current=1
							this.querySub(1)
						}
						else if(this.list.length%10==0 && type=='down'){
							this.current = this.current+1
							this.querySub(2)
						}
					}
				})
		},
		methods: {
			//sub/querySub 分包条件列表
			async querySub(e){
				var that = this
				const res = await this.$myReuqest({
					url:'sub/querySub',
					method:"POST",
					data:{
					  "current": that.current,
					  "minId": app.globalData.minId,
					  "size": 10,
					}
				})
				console.log(res)
				if(res.code==200){
					if(e==1){
						that.list = []
					}
					if(res.data){
						for(let i=0;i<res.data.list.length;i++){
							that.list.push(res.data.list[i])
						}
						// for(let i=0;i<10;i++){
						// 	that.list.push(res.data.list[0])
						// }
					}
					
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			creat(){ 
				console.log(1)
				uni.navigateTo({
					url:"/pages/subcontractor/sub-creat?type=1"
				})
			},
			detail(index){
				uni.navigateTo({
					url:'/pages/subcontractor/sub-detail?id='+this.list[index]['id']
				})
			}
		},
	}
</script>

<style>
	.title-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 110rpx 30rpx 70rpx 30rpx;	
	}
	.title{
		font-size: 36rpx;
		font-weight: 500;
		color: #232323;
	}
	.add-icon{
		width: 47rpx;
		height: 51rpx;
	}
	.groups{
		background: #F3F8FE;
		padding: 50rpx 30rpx 44rpx 30rpx;
		margin-bottom: 30rpx;
	}
	.level{
		/* width: 72rpx;
		height: 36rpx; */
		padding: 8rpx 20rpx;
		background: #14D6AF;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #FFFFFF;
		text-align: center;
	}
	.company-Name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-left: 20rpx;
	}
	.company{
		display: flex;
	}
	.orders{
		display: flex;
		align-items: center;
	}
	.orderid{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		line-height: 33rpx;
	}
	.order-type{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		line-height: 33rpx;
		margin-left: 20rpx;
	}
	.number{
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		line-height: 60rpx;
	}
	.words{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		line-height: 60rpx;
		margin-left: 12rpx;
	}
	.items{
		margin-top: 40rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
</style>
