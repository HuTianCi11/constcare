<template>
	<view class="">
		<view class="content">
			<view class="title">Task</view>
			<view class="select" @click="getSelect">
				<view class="">{{showName}}</view>
				<image src="../static/icon/down.png" class="select-img" mode="widthFix"></image>
			</view>
		</view>
		<u-select  v-model="show"  mode="single-column" :list="select"  @confirm="confirm"></u-select>
		<view class="task-group" v-for="(item,index) in list" @click="detail(item.id)">
			<view class="task-top">
				<view class="task-name"> 
					{{item.name}}
				</view>
				<view class="">
					<text class="subNum">{{item.subNum}}</text><text class="subword">Sub</text> <text class="subNum" style="margin-left: 30rpx;">{{item.workerNum}}</text><text  class="subword">Woker</text>
				</view>
			</view>
			
			<view class="task-content">
				<view class="">
					<view class="SiteName">
						{{item.conName}}
					</view>
					<view class="time">
						{{item.startDate}} ~{{item.endDate}}
					</view>
				</view>
				<view class="percent">
					{{item.percent}}%
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				current:1,
				list:[],
				show:false,
				select:[],
				showName:'Construction Site Name'
			}
		},
		mounted(){
			this.whereGEt(-1)
			uni.$on('test',(name,type)=>{
					console.log('监听task',name,type);
					if(name=='task'){
						if(type=='up'){
							this.current=1
							console.log('啦啦啦')
							this.showName = 'Construction Site Name'
							this.whereGEt(-1,type)
						}
						else if(this.list.length%10==0 && type=='down'){
							this.current=this.current+1
							this.whereGEt(-1,type)
						}
					}
				})
			
		},
		methods: {
			confirm(e){
				console.log(e)
				console.log(e[0]['value'])
				this.current=1
				this.showName = e[0]['label']
				this.whereGEt(e[0]['value'],'up')
			},
			async getSelect(){    
					console.log(app.globalData)
					var data={}
					if(app.globalData.identity==1){
						data['minId']=app.globalData.minId
					}else{
						data['subId']=app.globalData.subId
					}
					console.log(data)
					const res = await this.$myReuqest({
						url:'construction/appDropDown/',
						method:"GET",
						data:data,
						hidden:true
					})
					console.log(res)
					if(res.code==200){
						this.show = true
						for(let i=0;i<res.data.length;i++){
							this.select[i]={}
							this.select[i].value = res.data[i].id
							this.select[i].label = res.data[i].name
						}
						// this.select = res.data
						
					}else{
						uni.showToast({
							title:res.msg,
							icon:'none'
						})
					}
			},
			whereGEt(id,type=''){ //type 1常规加载, 2选择后加载
				var data
				console.log(type)
				if(app.globalData.identity==1){
					data={
						"current": this.current,
						"minId":app.globalData.minId,
						"size": 10,
					}
					if(id!=-1){data['conId']=id}
				}else{
					//分包商请求
					console.log(app.globalData)
					data={
						"current": this.current,
						"subId":app.globalData.subId,
						"size": 10,
					}
				}
				console.log(data)
				this.minTask(data,type)
				
			},
			async minTask(data,type){
				var that = this
				const res = await this.$myReuqest({
					url:'task/appTaskReq/',
					method:"POST",
					data:data
				})
				console.log(res)
				if(res.code==200){
					if(type=='up'){
						that.list=[]
					}
					if(res.data.list){
						for(let i=0;i<res.data.list.length;i++){
							let num = parseInt(res.data.list[i].percent*100)
							if (num>100){
								num=100
							}
							res.data.list[i].percent = num
							that.list.push(res.data.list[i])
						}
						// for(let i=0;i<10;i++){
						// 	that.list.push(res.data.list[0])
						// }
					}
					
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},

			
			detail(taskId){
				if(app.globalData.identity==1){
					uni.navigateTo({
						url:"/pages/task/task-detail-min?taskId="+taskId
					})
				}else{
					uni.navigateTo({
						url:"/pages/task/task-detail-sub?taskId="+taskId
					})
				}
				
			}
		},
	}
</script>

<style>
	.select-img{
		width: 36rpx;
		height: auto;
	}
	.content{padding: 80rpx  30rpx 0 30rpx;}
	.title{
		font-size: 36rpx;
		font-weight: 500;
		color: #232323;
		margin-top: 30rpx;
	}
	.select{
		margin-top: 50rpx;
		height: 70rpx;
		background: #FFFFFF;
		border: 1rpx solid #DEDFEC;
		color: #8B8F9E;
		font-size: 24rpx;
		display: flex;
		align-items:center;
		justify-content: space-between;
		padding:0 20rpx;
		margin-bottom: 52rpx;
	}
	.task-group{
		margin-bottom: 30rpx;
		background: #F3F8FE;
		padding: 30rpx;
	}
	.task-name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		line-height: 37rpx;
		width: 400rpx;
	}
	.subNum{
		font-size: 30rpx;
	}
	.subword{
		font-size: 20rpx;
		margin-left: 6rpx;
		color: #8B8F9E;
	}
	.task-top{
		display: flex;
		justify-content: space-between;
	}
	.SiteName{
		font-size: 24rpx;
		font-weight: 400;
		color: #585B66;
		line-height: 33rpx;
		margin-top: 40rpx;
	}
	.time{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		line-height: 33rpx;
		margin-top: 28rpx;
	}
	.percent{
		width: 75rpx;
		height: 75rpx;
		background: #22DF9B;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #FFFFFF;
		font-size: 20rpx;
		font-family: PingFang SC;
	}
	.task-content{
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 26rpx;
	}
</style>
