<template>
	<view>
		<view class="title-group" >
			<view class="title">Worker</view>
			<image v-if="creatShow" src="../static/icon/addto@3x.png"  @click="creat" class="add-icon"></image>
		</view>
		<view class="woker-group" v-for="(item,index) in list" @click="detail(item.id)">
			<view class="woker-item">
				<view class="workerInfo">
					<view class="workerName">{{item.username}}</view>
<!-- 					<image src="../static/icon/girl.png" class="img"></image> -->
					<!-- <image src="../static/icon/Singapore@3x.png" class="img"></image> -->
					<view class="county">{{item.nationality}}</view>
				</view>
				<view class="workType" :style="{background:item.type==0?'#FF8D13':'#36B9CC'}">
					{{item.type==0?'Working':'Resting'}}
				</view>
			</view>
			<view class="woker-item" style="margin-top: 30rpx ;"  >
				<view class="items">
					<view class="item-left">
						<view class="cardId">FIN Numbe</view>
						<view class="number">{{item.finNumber}}</view>
					</view>
					<view class="item-left" style="margin-top: 30rpx;">
						<view class="cardId" >Safety Card Id</view>
						<view class="number" >{{item.safetyCardId}}</view>
					</view>
				</view>
				<view class="dayNum">{{item.workDay}}<text class="day-text">Total Days</text></view>
			</view>
		</view>
		<!-- 测试 -->

	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				current:1,
				list:[],
				creatShow:false
			}
		},
		mounted(){
			var manager = uni.getStorageSync('manager');
			for(let i=0;i<manager.length;i++){
				if(manager[i]==35){
					this.creatShow=true
					break
				}
			}
			this.QueryWorkList()
			uni.$on('test',(name,type)=>{
					console.log('监听work',name,type);
					if(name=='work'){
						if(type=='up'){
							this.current=1
							this.QueryWorkList(type)
						}
						else if(this.list.length%10==0 && type=='down'){
							this.current=this.current+1
							this.QueryWorkList(type)
						}
					}
				})
		},
		methods: {
			async QueryWorkList(type=''){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/QueryWorkList/',
					method:"POST",
					data:{
						current:this.current,
						size : 10,
						subId:app.globalData.subId
					},
					// hidden:true
				})
				var test={
						current:this.current,
						size : 10,
						subId:app.globalData.subId
					}
				console.log(test,"work请求")
				if(res.code==200){
					if(type=='up'){
						that.list=[]
					}
					for(let i=0;i<res.data.records.length;i++){
						that.list.push(res.data.records[i])
					}
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			creat(){
				uni.navigateTo({
					url:"/pages/worker/worker-creat?type=1"
				})
			},
			detail(id){
				uni.navigateTo({
					url:'/pages/worker/worker-detail?id='+id
				})
			}
		},
	}
</script>

<style>
	.county{
		margin-left: 20rpx;
		font-size: 22rpx;
	}
	.day-text{
		margin-left: 10rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #6E707E;
	}
	.dayNum{
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
	}

	.item-left{
		display: flex;
		align-items: center;
		width: 100%;
	}
	.cardId{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		width: 180rpx;
	}
	.number{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.woker-group{
		padding: 30rpx 40rpx;
		background: #F3F8FE;
		margin-bottom: 30rpx;
	}
	.woker-item{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.workerInfo{
		display: flex;
		align-items: center;
	}
	.workType{
		border-radius: 18rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
		padding: 6rpx 12rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.workerName{
		margin-right: 10rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
	}
	.img{
		margin-left: 10rpx;
		width: 37rpx;
		height: 37rpx;
	}
	.title-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 110rpx 30rpx 70rpx 30rpx;		
	}
	.title{
		font-size: 36rpx;
		font-weight: 500;
		color: #232323;
	}
	.add-icon{
		width: 47rpx;
		height: 51rpx;
	}

</style>
