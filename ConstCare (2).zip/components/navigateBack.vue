<template>
	<view class="backGroup">
		<image src="/static/icon/back.png" mode="widthFix" class="back-img" @click="back"></image>
	</view>
</template>

<script>
	export default {
		props: {},
		methods: {
			back(){
				uni.navigateBack({
					delta:1
				})
			},
		},
	}
</script>

<style>
	.backGroup{
		position: fixed;
		left: 0;
		top: 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
/* 		padding: 20rpx 0; */
		z-index: 999;
		background: #FFFFFF;
		width: 100%;
		padding: 100rpx 0 20rpx 0;
	}
	.back-img{
		margin-left: 20rpx;
		width: 40rpx;
		height: auto;
	}
</style>
