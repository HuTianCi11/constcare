import Vue from 'vue'
import App from './App'

import uView from "uview-ui";
Vue.use(uView);

import { myReuqest} from "./utils/request.js"
Vue.prototype.$myReuqest = myReuqest

Vue.config.productionTip = false

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
