<template>
	<view  class="">
		<app-update ref="app_update" :force="false" :tabbar="false"></app-update>

		<view  v-if="identity==1">
			<SubHome v-if="PageIndex==0" ></SubHome>
			<TaskHome v-if="PageIndex==1"></TaskHome>
			<PwtHome v-if="PageIndex==2"></PwtHome>
			<MeHome v-if="PageIndex==3"></MeHome>
		</view>
		<view  v-else>
			<TaskHome v-if="PageIndex==0"></TaskHome>
			<PwtHome v-if="PageIndex==1"></PwtHome>
			<worker-home v-if="PageIndex==2"></worker-home>
			<MeHome v-if="PageIndex==3"></MeHome>
		</view>
		
		<view class="tabbar">
			<view class="bar-item" v-for="(item,index) in tabbar" @click='change(index)'>
				<image :src="PageIndex==index?item.selectedIconPath:item.iconPath" mode="widthFix" class="bar-icon"></image>
				<view :class="index==PageIndex?'no-text':'sel-text'">{{item.text}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	import SubHome from '../../components/SubHome.vue'
	import MeHome from '../../components/MeHome.vue'
	import WorkerHome from '../../components/WorkerHome.vue'
	import PwtHome from '../../components/PwtHome.vue'
	import TaskHome from '../../components/TaskHome.vue'
	import tabbar from '../..//utils/tabbar.js'
	import appUpdate from "@/components/yzhua006-update/app-update.vue"
	export default {
		components:{SubHome,MeHome,WorkerHome,PwtHome,TaskHome,appUpdate},
		data() {
			return {
				identity:"",
				PageIndex:0,
				tabbar:[],
			}
		},
		mounted() {
			this.$refs.app_update.update();  //调用子组件 检查更新
		},
		onLoad(e) {		
			var res = uni.getStorageSync('loginData');
			if(res){
				if(res.minId){
					app.globalData.minId = res.minId
					app.globalData.identity = 1 //min
					console.log("总包商")
					app.globalData.pageIndex = 'sub'
				}else{
					app.globalData.subId = res.subId
					app.globalData.identity = 2 //sub
					console.log("分包商")
					app.globalData.pageIndex = 'task'
				}
			}
			
			this.identity = app.globalData.identity
			if(e.index){
				this.PageIndex=e.index
				console.log(e.index,'e.index')
			}
			// this.wherePage(this.PageIndex)
			uni.$emit('test',this.wherePage(this.PageIndex),'up')
		},
		
		onShow(){
			this.tabbar = tabbar.bar[app.globalData.identity-1]
			this.test('up')
		},
		onReachBottom(){
			this.test('down')
		},
		onPullDownRefresh() {
			console.log('refresh');
			this.test('up')
			setTimeout(function () {
				uni.stopPullDownRefresh();
			}, 1000);
		},
		methods: {
			change(index){
				// uni.$emit('off',this.PageIndex)
				this.PageIndex = index
				this.wherePage(index)
			},
			test(type){
				uni.$emit('test',this.wherePage(this.PageIndex),type) // 页面  sub,task,worker,
			},
			wherePage(index){
				var pageIndex
				console.log(this.identity)
				if(this.identity==1){
					if(index==0) {
					    pageIndex = "sub";
					}else if(index==1){
						pageIndex = "task";
					}else if(index==2){
						pageIndex = "pwt";
					}
				}else{
					if(index==0) {
					    pageIndex = "task";
					}else if(index==1){
						pageIndex = "pwt";
					}else if(index==2){
						pageIndex = "work";
					}
					
				}
				console.log(index,pageIndex)
				app.globalData.pageIndex = pageIndex
				return pageIndex
				
			},
		},
	}
</script>

<style>
	page{
		background-color: #FFFFFF;
		padding-bottom: 110rpx;
	}
	.sel-text{
		color: #D3D4D7;
	}
	.no-text{
		color:#1890FF;
	}
	.tabbar{
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-around;
		align-items: center;
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		border-top: 1rpx solid rgb(243,243,243);
		font-size: 20rpx;
		/* #ifndef APP-NVUE */
		box-sizing: content-box;
		/* #endif */
	}
	.bar-item{
		width: 25%;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
		padding: 12rpx 0;
		height: 100%;
	}
	.bar-icon{
		width: 40rpx;
		height: auto;
	}
</style>
