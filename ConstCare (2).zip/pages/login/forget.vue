<template>
	<view class="">
		<navigateBack></navigateBack>
		<view class="content">
			<view class="title">
				Forget the password
			</view>
			<view class="input-group">
				<view class="tip">
					Email
				</view>
				<input type="text" v-model="email" class="login-input" placeholder-class="pla-class"   placeholder="Please input"/>
			</view>
			<button type="default" class="login" @click="confirm">Confirm</button>
		</view>
	</view>
</template>

<script>
	import navigateBack from '../../components/navigateBack.vue'
	export default {
		components:{navigateBack},
		data() {
			return {
				email:"",
				password:""
			}
		},
		onLoad() {
		},
		methods: {
			async confirm(data,type){
				var that = this
				const res = await this.$myReuqest({
					url:'user/forgetPwd/',
					method:"POST",
					data:{
						email:that.email
					}
				})
				console.log(res)
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
			},
		},
	}
</script>

<style>
	.content{padding: 0 75rpx;padding-top: 170rpx;}
	.title{margin-top: 60rpx;font-size: 48rpx;font-family: PingFang SC;color: #3E404A;line-height: 60rpx;}
	.input-group{margin-top: 156rpx;}
	.login-input{width: 540rpx;height: 80rpx;border: 1rpx solid #B7B9CC;border-radius: 40rpx;padding: 0 30rpx;}
	.pla-class{font-size: 24rpx;font-family: PingFang SC;color: #33343B;line-height: 60rpx;font-weight: 400;}
	.tip{font-size: 30rpx;color: #33343B;margin-bottom: 30rpx;}
	.login{margin-top: 594rpx;width: 600rpx;height: 80rpx;background: #1890FF !important;border-radius: 40rpx;color: #FFFFFF !important;display: flex;justify-content: center;align-items: center;font-size: 30rpx;}
	
</style>
