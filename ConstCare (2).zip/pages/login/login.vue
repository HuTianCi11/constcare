<template>
	<view class="content">
		<view class="logo">
			<image class="logo-img" src="/static/logo.png" mode="widthFix"></image>
		</view>
		
		<view class="input-group">
			<view class="login-input">
				<input v-model="email" type="text"  placeholder-class="pla-class"   placeholder="Email"/>
			</view>
			
			<view  class="login-pwd">
				<input v-model="pwd"  :type="showText" style="width: 80%;" placeholder-class="pla-class"  placeholder="Password"/>
				<u-icon  size="36" :name='iconName' color="#646464" @click="showPwd"></u-icon>
			</view>
<!-- 			<input v-model="pwd"  style="margin-top: 40rpx;" type="password" class="login-input" placeholder-class="pla-class"  placeholder="Password"/> -->
		</view>
		<button type="default" class="login" @click="doLogin">Login</button>
		<view class="forget" @click="forget">
			Forget the password?
		</view>
	</view>
</template>

<script>
	const app = getApp()
	import tabbar from '../../utils/tabbar.js'
	export default {
		data() {
			return {
				email:"",
				pwd:"",
				showText:"password",
				iconName:'eye-fill'
			}
		},
		onLoad() {
			var res = uni.getStorageSync('loginData');
			console.log(res,"loginData")
			if(res){
				if(res.minId){
					app.globalData.minId = res.minId
					app.globalData.identity = 1 //min
					console.log("总包商")
				}else{
					app.globalData.subId = res.subId
					app.globalData.identity = 2 //sub
					console.log("分包商")
				}
				this.jurisdiction(res.subId,res.roleId)
				uni.redirectTo({
					url:'../index/index'
				})
			}
			
		},
		methods: {
			showPwd(){
				if(this.showText=='password'){
					this.showText='text'
					this.iconName='eye-off'
				}else{
					this.showText='password'
					this.iconName='eye-fill'
				}
			},
			async jurisdiction(subId,id){ //按钮权限控制
				console.log(subId,id)
				var that = this
				const res = await this.$myReuqest({
					url:'role/getMenuById/',
					method:"GET",
					data:{
						id,
						subId
					},
					header:{'content-type': 'application/x-www-form-urlencoded'},
					hidden:true
				})
				// console.log(res,'权限返回')
				if(res.code==200){ 
					uni.setStorageSync('manager', res.data.menuIds);
				}
			},
			async doLogin(){ 
				var that = this
				const res = await this.$myReuqest({
					url:'user/doLogin',
					method:"POST",
					data:{
						email:that.email,
						pwd:that.pwd
					},
					header:{'content-type': 'application/x-www-form-urlencoded'}
				})
				console.log(res,'登录返回')
				if(res.code==200){
					uni.setStorageSync('loginData', res.data);
					if(res.data.minId){
						app.globalData.minId = res.data.minId
						app.globalData.identity = 1 //min
						console.log("总包商")
					}else{
						app.globalData.subId = res.data.subId
						app.globalData.identity = 2 //sub
						console.log("分包商")
						that.jurisdiction(res.data.subId,res.data.roleId)
					}
					uni.redirectTo({
						url:'../index/index'
					})
				}else{
					uni.showToast({
						title:res.msg,
						icon:"none"
					})
				}
				
			},
			login(){
				if(this.email.length<1){
					uni.showToast({
						title:"plese enter your account",
						icon:"none"
					})
					return
				}else if(this.pwd.length<1){
					uni.showToast({
						title:"Please enter your password",
						icon:"none"
					})
					return
				}else{
					this.doLogin()
				}
			},
			forget(){
				uni.navigateTo({
					url:"../login/forget"
				})
			}
		},
	}
</script>

<style>
	.content{padding: 90rpx 75rpx 0 75rpx;}
	.logo{display: flex;justify-content: center;align-items: center;margin-top: 180rpx;}
	.logo-img{width: 380rpx;height: auto;padding: 66rpx 0 ;}
	.input-group{margin-top: 120rpx;}
	.login-input{width: 100%;height: 90rpx;border: 1rpx solid #B7B9CC;border-radius: 80rpx;padding: 0 30rpx;display: flex;align-items: center;}
	.login-pwd{width: 100%;height: 90rpx;margin-top: 40rpx;
	border: 1rpx solid #B7B9CC;border-radius: 80rpx;padding: 0 30rpx;display: flex;justify-content: space-between;align-items: center;}
	.pla-class{font-size: 24rpx;font-family: PingFang SC;color: #33343B;line-height: 60rpx;font-weight: 400;}
	.login{width: 600rpx;height: 80rpx;background: #1890FF !important;border-radius: 40rpx;color: #FFFFFF !important;display: flex;justify-content: center;align-items: center;margin-top: 100rpx;font-size: 30rpx;}
	.forget{font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #1890FF;line-height: 60rpx;display: flex;justify-content: center;align-items: center;margin-top: 36rpx;}
</style>
