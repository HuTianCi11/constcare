<template>
	<view class="">
		<navigateBack></navigateBack>
		<view class="task-group" >
			<view class="task-name">
				Create  General Work
			</view>
			<view class="project-name">*Project / Contract No:</view>
			<input type="text" v-model="projectNo" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			
			<view class="project-name">*S/No. :</view>
			<input type="text" v-model="sno" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			
			<view class="project-name">*Validity Date. :</view>
			<view class="picker-date-group">
				<view class="picker-date-item">
					<view class="uni-input" @click="validaty_start_show=true" >{{validaty_start_time}}</view>
					<view class="line"></view>
					<view class="uni-input" @click="validaty_end_show=true">{{validaty_end_time}}</view>
				</view>
				<image src="../../static/icon/calendar@3x.png" class="date-img" mode=""></image>
			</view>
			<!-- validaty Date -->
			<u-picker confirm-text='confirm' @confirm="validaty_start" cancel-text='cancel'	 v-model="validaty_start_show" mode="time"></u-picker>
			<u-picker confirm-text='confirm' @confirm="validaty_end" cancel-text='cancel'	 v-model="validaty_end_show" mode="time"></u-picker>
				
			<view class="project-name">*Validity Time :</view>
			<view class="picker-time">
				<view class="picker-time-item">
<!-- 					<picker mode="time" style="width: 100%;padding: 0 20rpx 0 35rpx;" :value="time" start="09:01" end="21:01" @change="bindTimeChange"> -->
						<view class="uni-input2"  @click="validaty_start_time_show=true">
							<view class="">{{validaty_start_clock}}</view>
							<image src="../../static/icon/time@3x.png" class="date-img2" mode=""></image>
						</view>
			<!-- 		</picker> -->
				</view>
				<view class="line" style="margin: 0 24rpx;width: 30rpx;"></view>
				<view class="picker-time-item">
				<!-- 	<picker style="width: 100%;padding: 0 20rpx 0 35rpx;" mode="time" :value="time" start="09:01" end="21:01" @change="bindTimeChange"> -->
						<view class="uni-input2" @click="validaty_end_time_show=true">
							<view class="">{{validaty_end_clock}}</view>
							<image src="../../static/icon/time@3x.png" class="date-img2" mode=""></image>
						</view>
			<!-- 		</picker> -->
				</view>
			</view>
			<u-picker confirm-text='confirm' :params='params'  @confirm="_validaty_start_clock" cancel-text='cancel'	 v-model="validaty_start_time_show" mode="time"></u-picker>
			<u-picker confirm-text='confirm' :params='params' @confirm="_validaty_end_clock" cancel-text='cancel'	 v-model="validaty_end_time_show" mode="time"></u-picker>
			
			
		</view>
		
		<view class="part-group" >
			<view class="part-title" style="margin-bottom: 46rpx;">Part1: Application General Information</view>
			<view class="project-name">*Name of Applicant (Supervisor Level and Above):</view>
			<input v-model="p1Name" type="text" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			<view class="project-name">*Date and Time of Application</view>
			<view class="picker-time">
				<view class="picker-time-item">
					<view class="uni-input2" @click="app_date_show=true">
						<view class="">{{app_date}}</view>
						<image src="../../static/icon/calendar@3x.png" class="date-img" mode=""></image>
					</view>
				</view>
				<view class="line" style="margin: 0 24rpx;width: 30rpx;"></view>
				<view class="picker-time-item">
					<view class="uni-input2" @click="app_time_show=true">
						<view class="">{{app_time}}</view>
						<image src="../../static/icon/time@3x.png" class="date-img2" mode=""></image>
					</view>
				</view>
			</view>
			<u-picker confirm-text='confirm'  @confirm="_app_date" cancel-text='cancel'	 v-model="app_date_show" mode="time"></u-picker>
			<u-picker confirm-text='confirm' :params='params' @confirm="_app_time" cancel-text='cancel'	 v-model="app_time_show" mode="time"></u-picker>
			
			<view style="margin-top: 42rpx;" class="project-name">*Location of Work</view>
			<input type="text" v-model="p1Work" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			<view class="project-name">*Nature of Works:</view>
			<input type="text" v-model="p1Nature" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
		</view>
		
		<view class="part-group" >
			<view class="part-title">Part 2:Evaluation of Condition Required for Works</view>
			<view class="part-above" style="font-size: 24rpx;margin-bottom: 45rpx;">Safety and Health Site Inspection bY Site Supervisor</view>
			<view class="" v-for="(items,indexs) in workers">
				<view class="wokers-title" style="word-break:break-all;">{{items.name}}</view>
				<view class="wokers-group">
					<view @click="checkWeek(indexs,index)" :class="item.click?'sel-work':'no-work'" v-for="(item,index) in items.checked">{{item.day}}</view>
				</view>
			</view>
			
			<view class="parties">Daily initial Signature by Respective parties:</view>
			<!-- 表格 -->
			<scroll-view scroll-x style="width: auto;overflow:hidden;"  show-scrollbar	>
				<view class="table-group" style="width: 1200rpx;">
					<view class="table-item" style="height: 80rpx;">
						<view class="table-tile-s" >Day</view>
						<view class="table-titles" style="height: 80rpx;" v-for="(item,index) in week" :key="index">
							{{item}}
						</view>
					</view>
					<view class="table-item">
						<view class="table-tile">Date</view>
						<view class="table-titles table-border"  v-for="(item,index) in agree.date" :key="index" @click="_table_date_show(index)" >
							<view class="pla-num-in"  v-if="index==0" >
								<view class="">{{table_date.day}}</view>
								<view class="">{{table_date.year}}</view>
							</view>
						</view>
					</view>
				<!-- 	<u-picker confirm-text='confirm' max-date='2050-01-01	'  @confirm="table_date" cancel-text='cancel' v-model="table_date_show" mode="time"></u-picker> -->
				<u-calendar  @change='table_date' v-model="table_date_show"   mode="date"></u-calendar>
					<view class="table-item">
						<view class="table-tile">Site supervisor Signature</view>
						<view class="table-titles table-border"  v-for="(item,index) in agree.site" :key="index">
							<view class="pla-num-in"  v-if="index==0">2</view>
						</view>
					</view>
					<view class="table-item">
						<view class="table-tile">Total Manpower</view>
						<view class="table-titles table-border"  v-for="(item,index) in agree.total" :key="index">
							<view class=""  v-if="index==0">
								<input type="number" value="" v-model="people" class="pla-num-in"  placeholder="" placeholder-class="pla-num"/>
							</view>
						</view>
					</view>
				</view>
			</scroll-view>
			<view class="project-name" style="margin-top: 40rpx;">*Name</view>
			<input type="text" v-model="p2SignName" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			
			<view class="project-name">*Designation</view>
			<input type="text" v-model="p2Desc" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			
		</view>
		<view class="" style="padding-bottom: 90rpx;">
			<view class="part-group" style="margin-bottom: 60rpx;">
				<view class="part-title" style="margin-bottom: 42rpx;">Part3: Approved*/Not Approved* By Approval by 
Project Manager/ Authorized Manager</view>
				<view class="project-name">*Name</view>
				<input type="text" v-model="p3SignName" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="project-name">*Designation</view>
				<input type="text" v-model="p3Desc" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			</view>
		</view>
		
		
		<!-- 底部 -->
		<view class="btn-bottom" @click="creat_PWT">
			<image src="../../static/icon/submit@3x.png" class="btn-img"></image>
			<view class="">Submit</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	import navigateBack from '../../components/navigateBack.vue'
	export default {
		components:{navigateBack},
		data() {
			return {
				workers:[
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"a) lsolation done prior to works?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"b) PPE provisioned and donned safely?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"c) ls task required lighting? (if yes,provide detail below)"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"d) No incompatible works?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"e) Work at Height Permit required?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"f) Confined Space Entry Permit required?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"g) Hot Works Permit required?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"h) Are all workmen made aware of the hazards and safety precautions?"
					},
					{
						checked:[
							{day:'M',click:true},{day:'T',click:false},{day:'W',click:false},{day:'T',click:false},{day:'F',click:false},{day:'S',click:false},{day:'S',click:false},
						],
						name:"i) Are all workmen briefed on the emergency procedure and escape route(s)?"
					}
				
				],
				titles:[
					"Day","Date",'Site supervisor Signature','Total Manpower'
				],
				week:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
				agree:{
					date:[{'day':1},{'day':0},{'day':0},{'day':0},{'day':0},{'day':0},{'day':0}],
					site:[{'day':0},{'day':1},{'day':0},{'day':0},{'day':0},{'day':0},{'day':0}],
					total:[{'day':0},{'day':0},{'day':1},{'day':0},{'day':0},{'day':0},{'day':0}],
				},
				startDate:"",
				endDate:"",
				date:'',
				time:'',
				validaty_start_show:false,
				validaty_end_show:false,
				validaty_start_time:"Start time",
				validaty_end_time:"End time",
				validaty_start_year:"",
				validaty_start_month:"",
				validaty_start_day:"",
				validaty_start_time_show:false,
				validaty_end_time_show:false,
				validaty_start_clock :"06:00",
				validaty_end_clock :"08:00",
				params:{'hour': true,'minute': true},
				validaty_start_clock_hour:'',
				validaty_start_clock_minute:'',
				app_date:"",
				app_time:"",
				app_date_show:false,
				app_time_show:false,
				
				loginData:"",
				////////////////pwt 
				projectNo:"",
				sno:"",
				p1Name:"",
				p1Work:"",
				p1Nature:"",
				p3Desc: '',
				p3SignName: '',
				p2Desc: '',
				p2SignName: '',
				//表格选的日期
				table_date_year:"",
				table_date_day:"",
				table_date_month:"",
				table_date_show:false,
				//日历选择
				
				people:"",
				p1Daliy1Date:"",
				
				
			}
		},
		onLoad() {
			this.app_date = this.getTime(1)
			this.app_time = this.getTime(2)
			this.loginData = uni.getStorageSync('loginData')
		},
		methods: {
			_table_date_show(e){
				if(e==0){
					this.table_date_show=true
				}
			},
			checkWeek(indexs,index){
				console.log(indexs,index)
				var workers = this.workers
				if(workers[indexs]['checked'][index]['click']==true){
					workers[indexs]['checked'][index]['click']=false
				}else{
					workers[indexs]['checked'][index]['click']=true
				}
				this.workers = workers
			},
			_app_date(e){
				this.app_date = e.year+"-"+e.month+'-'+e.day
			},
			_app_time(e){
				this.app_time = e.hour+":"+e.minute
			},
			validaty_start(e){
				console.log(e)
				this.validaty_start_year = parseInt(e.year)
				this.validaty_start_month = parseInt(e.month)
				this.validaty_start_day = parseInt(e.day)
				this.validaty_start_time = e.year+"-"+e.month+'-'+e.day
				
			},
			validaty_end(e){
				var year = parseInt(e.year)
				var month = parseInt(e.month)
				var day = parseInt(e.day)
				if(this.validaty_start_time=='start time'){
					uni.showToast({
						title:'Please try again',
						icon:"none"
					})
					return
				}
				if(this.validaty_start_year>year){
					uni.showToast({
						title:'Please try again',
						icon:"none"
					})
				}else if(this.validaty_start_year<=year){
					if(this.validaty_start_month>month){
						uni.showToast({
							title:'Please try again',
							icon:"none"
						})
					}else if(this.validaty_start_day>day){
						uni.showToast({
							title:'Please try again',
							icon:"none"
						})
					}else{
						this.validaty_end_time = e.year+"-"+e.month+'-'+e.day
					}
				}
				else{
					this.validaty_end_time = e.year+"-"+e.month+'-'+e.day
				}
				
			},
			_validaty_start_clock(e){
				this.validaty_start_clock_hour = parseInt(e.hour)
				this.validaty_start_clock_minute = parseInt(e.minute)
				this.validaty_start_clock = e.hour +":"+e.minute
			},
			_validaty_end_clock(e){
				var hour = parseInt(e.hour),minute =parseInt(e.minute)
				if(hour<this.validaty_start_clock_hour){
					uni.showToast({
						title:'Please try again',
						icon:"none"
					})
				}else if(hour==this.validaty_start_clock_hour && minute<=this.validaty_start_clock_minute){
					uni.showToast({
						title:'Please try again',
						icon:"none"
					})
				}
				else{
					this.validaty_end_clock = e.hour +":"+e.minute
				}
				
			},
			getTime(type){
				//获取当前时间
				var date = new Date();
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				var day = date.getDate();
				var hour = date.getHours()
				var min = date.getMinutes()
				if (month < 10) {
				    month = "0" + month;
				}
				if (day < 10) {
				    day = "0" + day;
				}
				if (hour < 10) {
				    hour = "0" + hour;
				}
				if (min < 10) {
				    min = "0" + min;
				}
				var nowDate
				if(type==1){
					nowDate = year + "-" + month + "-" + day;
				}else{
					nowDate =hour+":"+min
				}
				return nowDate
			},
			
			table_date(e){
				console.log(e)
				if(e.week=='星期一'){
					this.table_date.year = e.year
					this.table_date.day = e.day+"/"+e.month
					if(e.month<10){
						e.month="0"+e.month
					}
					if(e.day<10){
						e.day="0"+e.day
					}
					this.p1Daliy1Date = e.year+"-"+e.month+"-"+e.day
				}
				
			},
			
			async creat_PWT(){
				var that = this
				const res = await this.$myReuqest({
					url:'ptw/creatPTW',
					method:"POST",
					data:{
					  subId: app.globalData.subId, //总包商的id
					  createUserId: this.loginData.id, //登录的id
					  //第一行
					  projectNo: this.projectNo,
					  sno: this.sno,
					  
					  validityStartDate: this.validaty_start_time,
					  validityEndDate: this.validaty_end_time,
					  validityStartHr: this.validaty_start_clock,
					  validityEndHr: this.validaty_end_clock,
					  //part1
					  p1Name: this.p1Name,
					  p1Nature: this.p1Nature,
					  p1Work: this.p1Work,
					  p1Time: this.app_date+this.app_time,
					  p1SignPath: this.loginData.signPath, //签名图片
					  createTime: new Date(), //创建时间
					  // A
					  p1A1: this.workers[0]['checked'][0].click,
					  p1A2: this.workers[0]['checked'][1].click,
					  p1A3: this.workers[0]['checked'][2].click,
					  p1A4: this.workers[0]['checked'][3].click,
					  p1A5: this.workers[0]['checked'][4].click,
					  p1A6: this.workers[0]['checked'][5].click,
					  p1A7: this.workers[0]['checked'][6].click,
					  // B
					  p1B1: this.workers[1]['checked'][0].click,
					  p1B2: this.workers[1]['checked'][1].click,
					  p1B3: this.workers[1]['checked'][2].click,
					  p1B4: this.workers[1]['checked'][3].click,
					  p1B5: this.workers[1]['checked'][4].click,
					  p1B6: this.workers[1]['checked'][5].click,
					  p1B7: this.workers[1]['checked'][6].click,
					  // C
					  p1C1: this.workers[2]['checked'][0].click,
					  p1C2: this.workers[2]['checked'][1].click,
					  p1C3: this.workers[2]['checked'][2].click,
					  p1C4: this.workers[2]['checked'][3].click,
					  p1C5: this.workers[2]['checked'][4].click,
					  p1C6: this.workers[2]['checked'][5].click,
					  p1C7: this.workers[2]['checked'][6].click,
					  // D
					  p1D1: this.workers[3]['checked'][0].click,
					  p1D2: this.workers[3]['checked'][1].click,
					  p1D3: this.workers[3]['checked'][2].click,
					  p1D4: this.workers[3]['checked'][3].click,
					  p1D5: this.workers[3]['checked'][4].click,
					  p1D6: this.workers[3]['checked'][5].click,
					  p1D7: this.workers[3]['checked'][6].click,
					  // E
					  p1E1: this.workers[4]['checked'][0].click,
					  p1E2: this.workers[4]['checked'][1].click,
					  p1E3: this.workers[4]['checked'][2].click,
					  p1E4: this.workers[4]['checked'][3].click,
					  p1E5: this.workers[4]['checked'][4].click,
					  p1E6: this.workers[4]['checked'][5].click,
					  p1E7: this.workers[4]['checked'][6].click,
					  // F
					  p1F1: this.workers[5]['checked'][0].click,
					  p1F2: this.workers[5]['checked'][1].click,
					  p1F3: this.workers[5]['checked'][2].click,
					  p1F4: this.workers[5]['checked'][3].click,
					  p1F5: this.workers[5]['checked'][4].click,
					  p1F6: this.workers[5]['checked'][5].click,
					  p1F7: this.workers[5]['checked'][6].click,
					  //G
					  p1G1: this.workers[6]['checked'][0].click,
					  p1G2: this.workers[6]['checked'][1].click,
					  p1G3: this.workers[6]['checked'][2].click,
					  p1G4: this.workers[6]['checked'][3].click,
					  p1G5: this.workers[6]['checked'][4].click,
					  p1G6: this.workers[6]['checked'][5].click,
					  p1G7: this.workers[6]['checked'][6].click,
					  // H
					  p1H1: this.workers[7]['checked'][0].click,
					  p1H2: this.workers[7]['checked'][1].click,
					  p1H3: this.workers[7]['checked'][2].click,
					  p1H4: this.workers[7]['checked'][3].click,
					  p1H5: this.workers[7]['checked'][4].click,
					  p1H6: this.workers[7]['checked'][5].click,
					  p1H7: this.workers[7]['checked'][6].click,
					  // I
					  p1I1: this.workers[8]['checked'][0].click,
					  p1I2: this.workers[8]['checked'][1].click,
					  p1I3: this.workers[8]['checked'][2].click,
					  p1I4: this.workers[8]['checked'][3].click,
					  p1I5: this.workers[8]['checked'][4].click,
					  p1I6: this.workers[8]['checked'][5].click,
					  p1I7: this.workers[8]['checked'][6].click,
					  p1J1: true,
	                  p1J2: true,
	                  p1J3: true,
	                  p1J4: true,
	                  p1J5: true,
	                  p1J6: true,
	                  p1J7: true,
					  //表格
					  p1Daliy1Total: this.people, //人数
					  p1Daliy1Date: this.p1Daliy1Date, //日期
					  p1Daliy1SignUserEmail: this.loginData.email, //邮箱
					  p1Daliy1SignDatetime: new Date(), //签名时间
					  p1Daliy1Sign:this.loginData.signPath, //登录的签名图片
					  p1Daliy1SignUserName: this.loginData.userName, //登录的用户名
					  p1Daliy1SignUserId: this.loginData.id, //登录的id
					  // part2
					  p2Desc: this.part2Design,
					  p2SignName: this.part2Name,
					  //part3
					  p3Desc: this.p3Desc,
					  p3SignName: this.p3SignName,

					}
				})
				console.log(res)
				if(res.code==200){
					uni.showToast({
						title:res.msg,
						duration:1500
					})
					setTimeout(()=>{
						uni.redirectTo({
							url:"/pages/index/index?index=1"
						})
					},1500)
				
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			}
		},
	}
</script>

<style>
	.pla-num-in{
		font-size: 16rpx;
		text-align: center;
	}
	.pla-num{
		font-size: 16rpx;
		text-align: center;
	}
	.picker-time-item{
		border: 1rpx solid #DEDFEC;
		width: 100%;
		height: 70rpx;
		display: flex;
		align-items: center;
	}
	.picker-time{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.uni-input2{
		padding: 0 20rpx 0 35rpx;
		display: flex;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		align-items: center;
		justify-content: space-between;
		width: 100%;
		/* padding: 0 0 0 35rpx; */
	}
	.picker-date-group{
		display: flex;
		align-items: center;
		justify-content: space-between;
		border: 1px solid #DEDFEC;
		padding:0 20rpx ;
		margin-bottom: 20rpx;
	}
	.uni-input{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		padding: 0rpx;
		text-align: center;
	}
	.picker-date-item{
		width: 100%;
		padding: 8rpx 0 ;
		display: flex;
		align-items: center;
		justify-content: space-around;
	}
	.picker-end{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.date-img{
		width: 24rpx;
		height: 24rpx;
	}
	.date-img2{
		width: 26rpx;
		height: 26rpx;
	}
	.line{
		width: 15rpx;
		height: 1rpx;
		background: #B7B9CC;
	}
	.btn-img{
		width: 30rpx;
		height: 30rpx;
	}
	.project-name{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 20rpx;
	}
	.input-class{
		height: 70rpx;
		background: #FFFFFF;
		border: 1px solid #DEDFEC;
		border-radius: 5rpx;
		margin-bottom: 40rpx;
		padding: 0 20rpx;
	}
	.pla-class{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.btn-text{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
		margin-left: 14rpx;
	}
	.btn-img{
		width: 30rpx;
		height: 30rpx;
		margin-right: 10rpx;
	}
	.btn-bottom{
		display: flex;
		align-items: center;
		width: 100%;
		position: fixed;
		bottom: 0;
		left: 0;
		background: #14D6AF;
		color: #FFFFFF;
		height: 100rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.table-border{
		font-weight: bolder !important;
		border-top:1px solid #DEDFEC;
	}
	.table-group{
		border: 1px solid #DEDFEC;
		border-right:0;
		margin-top:30rpx;
	}
	.table-item{
		display: flex;
		align-items: center;
		height: 120rpx;
	}
	.table-titles{
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		border-left: 1px solid #DEDFEC;
		/* text-align: center; */
		/* width: 66rpx;
		height: 60rpx; */
		width: 200rpx;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.table-tile-s{
		height: 80rpx;
		padding-left: 20rpx;
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		/* width: 228rpx; */
		width: 300rpx;
		display: flex;
		align-items: center;
	}
	.table-tile{
		height: 120rpx;
		padding-left: 20rpx;
	/* 	border-right: 1px solid #DEDFEC; */
		border-top: 1px solid #DEDFEC;
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		/* width: 228rpx;
		 */
		width: 300rpx;
		display: flex;
		align-items: center;
	}
	page{
		background-color: rgb(243,248,254);
	}
	.parties{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		padding-top: 22rpx;
	}
	.wokers-title{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.sel-work{
		width: 36rpx;
		height: 36rpx;
		background: #1890FF;
		border-radius: 2rpx;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-right: 10rpx;
	}
	.no-work{
		margin-right: 10rpx;
		width: 36rpx;
		height: 36rpx;
		background: #F4F4F4;
		border-radius: 2rpx;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #8B8F9E;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.wokers-group{
		margin-bottom: 30rpx;
		margin-top: 12rpx;
		display: flex;
		align-items: center;
	}
	.part-group{
		margin-top: 30rpx;
		background-color: #FFFFFF;
		padding: 40rpx 30rpx 20rpx 30rpx;
	}
	.part-title{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.part-above{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-top: 22rpx;
	}

	.task-group{
		padding: 190rpx 30rpx 56rpx 30rpx;
		background-color: #FFFFFF;
	}
	.task-name{
		margin-bottom: 50rpx;
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
</style>
