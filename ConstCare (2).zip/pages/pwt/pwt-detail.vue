<template>
	<view class="">
		<navigateBack></navigateBack>
		<view class="task-group" >
			<view class="task-name">
				General Work Detail
			</view>
		</view>
		<view class="groups">
			<view class="project" style="margin-bottom: 30rpx;">
				<view class="project-Name">{{pwt.projectNo}}</view>
				<view class="whp">{{pwt.sno}}</view>
			</view>
			<view class="project" style="margin-bottom: 20rpx;">
				<view class="project-date">{{pwt.validityStartDate}} to {{pwt.validityEndDate}}</view>
				<view class="state">S/NO</view>
			</view>
			<view class="project">
				<view class="project-hour">{{pwt.validityStartHr}} hr  to {{pwt.validityEndHr}} hr</view>
				<view class="process-group"  >
					<view class="process" :class="'color'+pwt.p1SignStatus" ></view>
					<view class="process" :class="'color'+pwt.p2SignStatus" ></view>
					<view class="process" :class="'color'+pwt.p3SignStatus" ></view>
					<view v-if="pwt.p4ApplyType">
						<view class="process" :class="'color'+pwt.p4SignStatus" ></view>
					</view>
					<view  v-else>
						<view class="process colorgray" ></view>
					</view>
				</view>
			</view>
		</view>
		
		<view class="part-group">
			<view class="part-title">Part 1: Application General Information</view>
			<view class="part-above">*Name of Applicant (Supervisor Level and Above):</view>
			<view class="part-userName">{{pwt.p1Name}}</view>
			
			<view class="userInfo-group" style="padding-bottom: 20rpx;">
				<view class="userInfo-item" style="width: 65%;">
					<view class="userInfo" style="height: 160rpx;">
						<view class="user-name">*Signature</view>
						<view class="signDig">
<!-- 								<image src="../../static/icon/Singapore@3x.png" class="picture"  @click="seeImg(pwt.p2SignPath)"></image> -->
							<image :src="pwt.p1SignPath" class="picture"  @click="seeImg(pwt.p1SignPath)"></image>
							<view class="signText" style="width: 300rpx;margin-top: 30rpx;" v-if="pwt.p1Daliy1Date">
								<view class="signsize">Digitally signed by:{{pwt.p1Name}}</view>
								<view class="signsize">{{pwt.p1Daliy1SignUserEmail}}</view>
								<view class="signsize">Date:{{pwt.p1Daliy1Date}}</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			
			<view class="part-date">*Date and Time of Application</view>
			<view class="part-date-item">
				<view class="part-yesr">{{p1Time[0]}} </view>
				<view class="part-clock">{{p1Time[1]}}</view>
			</view>
			<view class="part-work">*Location of Work:</view>
			<view class="part-content">{{pwt.p1Work}}</view>
			<view class="part-work">*Nature of Works:</view>
			<view class="part-content">{{pwt.p1Nature}}</view>
		</view>
		<view class="part-group" style="margin-top: 30rpx;">
			<view class="part-title">Part 2:Evaluation of Condition Required for Works</view>
			<view class="part-above" style="font-size: 24rpx;margin-bottom: 45rpx;">Safety and Health Site Inspection bY Site Supervisor</view>
			
			<view class="" v-for="(items,indexs) in workers">
				<view class="wokers-title" style="word-break:break-all;">{{items.name}}</view>
				<view class="wokers-group">
					<view @click="checkWeek(indexs,index)" :class="item.click?'sel-work':'no-work'" v-for="(item,index) in items.checked">{{item.day}}</view>
				</view>
			</view>
			<view class="parties">Daily initial Signature by Respective parties:</view>
			<!-- 表格 -->
			<scroll-view scroll-x style="width: auto;overflow:hidden;"  show-scrollbar	>
				<view class="table-group" style="width: 2400rpx;">
					<view class="table-item" style="height: 80rpx;">
						<view class="table-tile-s" >Day</view>
						<view class="table-titles" style="height: 80rpx;" v-for="(item,index) in week" :key="index">
							{{item}}
						</view>
					</view>
					<view class="table-item">
						<view class="table-tile">Date</view>
						<view class="table-titles table-border"  v-for="(item,index) in agree.date" :key="index">
							<view class="pla-num-in"  >
								<view class="">{{item.time}}</view>
								<view class="">{{item.date}}</view>
							</view>
						</view>
					</view>
					<view class="table-item" style="height: 260rpx;">
						<view class="table-tile" style="height: 260rpx;">Site supervisor Signature</view>
						<view class="table-titles table-border" style="height: 260rpx;"  v-for="(item,index) in agree.site" :key="index">
							<view class="signGroup" >
								<view class="signItem" @click="seeImg(item.img)" >
									<image class="signImg" :src="item.img" mode="widthFix"></image>
<!-- 									<image class="signImg" src="../../static/img.png" mode="widthFix"></image> -->
								</view>
								<view class="signText" v-if="item.date">
									<view class="">Digitally signed by:{{item.name}}</view>
									<view class="">{{item.email}}</view>
									<view class="">Date:{{item.date}}</view>
								</view>
							</view>
						</view>
					</view>
					<view class="table-item">
						<view class="table-tile">Total Manpower</view>
						<view class="table-titles table-border"  v-for="(item,index) in agree.total" :key="index">
							<view class="">{{item.num}}</view>
						</view>
					</view>
				</view>
			</scroll-view>
		</view>
		<!-- part 2: -->
		<view class="sign-group">
			<view class="sign-item">
				<view class="part-title">Part 2:Evaluation of Condition Required for Works</view>
				<view class="userInfo-group">
					<view class="userInfo-item" style="width: 35%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Name</view>
							<view class="user-date">{{pwt.p2SignName}}</view>
						</view>
					</view>
					<view class="userInfo-item" style="width: 65%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Signature</view>
							<view class="signDig">
<!-- 								<image src="../../static/icon/Singapore@3x.png" class="picture"  @click="seeImg(pwt.p2SignPath)"></image> -->
								<image :src="pwt.p2SignPath" class="picture"  @click="seeImg(pwt.p2SignPath)"></image>
								<view class="signText" style="width: 300rpx;" v-if="pwt.p2SignDatetime">
									<view class="signsize">Digitally signed by:{{pwt.p2SignName}}</view>
									<view class="signsize">{{pwt.p2SignEmail}}</view>
									<view class="signsize">Date:{{pwt.p2SignDatetime}}</view>
								</view>
							</view>
							
						</view>
					</view>
				</view>
			</view>
			<!-- Part 3 -->
			<view class="sign-item" >
				<view class="part-title">Part 3: Approved*/Not Approved* By Approval by Project Manager/ Authorized Manager</view>
				<view class="userInfo-group">
					<view class="userInfo-item" style="width: 35%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Name</view>
							<view class="user-date">{{pwt.p3SignName}}</view>
						</view>
					</view>
					<view class="userInfo-item" style="width: 65%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Signature</view>
							<view class="signDig">
<!-- 								<image src="../../static/icon/Singapore@3x.png" class="picture"  @click="seeImg(pwt.p2SignPath)"></image> -->
								<image :src="pwt.p3SignPath" class="picture"  @click="seeImg(pwt.p3SignPath)"></image>
								<view class="signText" style="width: 300rpx;" v-if="pwt.p3SignDatetime">
									<view class="signsize">Digitally signed by:{{pwt.p3SignName}}</view>
									<view class="signsize">{{pwt.p3SignEmail}}</view>
									<view class="signsize">Date:{{pwt.p3SignDatetime}}</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<!-- Part 4 -->
			<view class="sign-item">
				<view class="part-title">Part 4: Closure of Permit-to-work</view>
				<view class="userInfo-group">
					<view class="userInfo-item" style="width: 35%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Name</view>
							<view class="user-date">{{pwt.p4SignName}}</view>
						</view>
					</view>
					<view class="userInfo-item" style="width: 65%;">
						<view class="userInfo" style="height: 160rpx;">
							<view class="user-name">*Signature</view>
							<view class="signDig">
<!-- 								<image src="../../static/icon/Singapore@3x.png" class="picture"  @click="seeImg(pwt.p2SignPath)"></image> -->
								<image :src="pwt.p4SignPath" class="picture"  @click="seeImg(pwt.p4SignPath)"></image>
								<view class="signText" style="width: 300rpx;" v-if="pwt.p4SignDate">
									<view class="signsize">Digitally signed by:{{pwt.p4ApplyName}}</view>
									<view class="signsize">{{pwt.p4SignEmail}}</view>
									<view class="signsize">Date:{{pwt.p4SignDate}}</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>

		<!-- 底部 -->
<!-- 		<view class="btn-bottom">
			<view class="btn-item" style="background-color: #1890FF;">
				<image class="btn-img" src="../../static/icon/adopt@3x.png" mode=""></image>
				<view class="btn-text">Adopt</view>
			</view>
			<view class="btn-item" style="background-color: #E74A3B;">
				<image class="btn-img" src="../../static/icon/refuse@3x.png" mode=""></image>
				<view class="btn-text">Refuse</view>
			</view>	
		</view> -->
	</view>
</template>

<script>
	import navigateBack from '../../components/navigateBack.vue'
	export default {
		components:{navigateBack},
		data() {
			return {
				p1Time:"",
				titles:[
					"Day","Date",'Site supervisor Signature','Total Manpower'
				],
				week:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
				agree:{
					date:[{date:'',time:''},{date:'',time:''},{date:'',time:''},{date:'',time:''},{date:'',time:''},{date:'',time:''},{date:'',time:''}],
					site:[
						{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''},{name:"",img:'',date:'',email:''}
						],
					total:[{num:""},{num:""},{num:""},{num:""},{num:""},{num:""},{num:""}],
				}
			}
		},
		onLoad(opt) {
			this.pwt = JSON.parse(decodeURIComponent(opt.data))
			var start,end
			start = this.pwt.validityStartDate.split('-')
			end = this.pwt.validityEndDate.split('-')
			this.pwt.validityStartDate = start[2]+"/"+start[1]+'/'+start[0]
			this.pwt.validityEndDate = end[2]+"/"+end[1]+'/'+end[0]
			this.p1Time = this.pwt.p1Time.split('  ')
			var p1Time_date= this.p1Time[0].split('-')
			this.p1Time[0] = p1Time_date[2]+"/"+p1Time_date[1]+'/'+p1Time_date[0]
			//woker type
			var workers
			if(this.pwt.workType){
				workers = [
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"a) Workers issued and trained on the use of safety belts / harness and use them for work?b)All fall protections are in place and are effective for the works intended?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"b)  All fall protections are in place and are effective for the works intended?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"c) Fall protections (lifeline, anchorage point, guardrails, toe-boards) in good condition?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"d) Scaffoldings and ladders used are inspected and in good working condition?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"e) Workers are protected from falling objects?  Falling objects are effective contained?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"f) is task required lighting?  (if yes, provide detail below)"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"g) No incompatible works?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"h) Proper, safe and continuous access way provided for works?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"i) Are all workmen made aware of the hazards and safety precautions?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"j) Are all workmen briefed on the emergency procedure and escape route(s)?"
					}

				]
			}else{
				workers = [
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"a) lsolation done prior to works?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"b) PPE provisioned and donned safely?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"c) ls task required lighting? (if yes,provide detail below)"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"d) No incompatible works?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"e) Work at Height Permit required?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"f) Confined Space Entry Permit required?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"g) Hot Works Permit required?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"h) Are all workmen made aware of the hazards and safety precautions?"
					},
					{
						checked:[
							{day:'M',click:0},{day:'T',click:0},{day:'W',click:0},{day:'T',click:0},{day:'F',click:0},{day:'S',click:0},{day:'S',click:0},
						],
						name:"i) Are all workmen briefed on the emergency procedure and escape route(s)?"
					}

				]
			}
			
			var words = ['A',"B",'C','D','E','F','G','H','I','J']
			for(let i=0;i<workers.length;i++){
				for(let j=0;j<workers[i]['checked'].length;j++){
					let num = j+1
					workers[i]['checked'][j]['click'] = this.pwt['p1'+words[i]+num]
				}
			}
			this.workers= workers
			for(let i=0;i<this.agree.date.length;i++){
				let num = i+1
				//日期
				let  date =  this.pwt['p1Daliy'+num+'Date'].split(' ')[0]
				this.agree.date[i]['date']=date.split('-')[0]
				this.agree.date[i]['time']=date.split('-')[2]+'/'+date.split('-')[1]
				//人数
				this.agree.total[i]['num'] = this.pwt['p1Daliy'+num+'Total']
				//签名
				this.agree.site[i]['name'] = this.pwt['p1Daliy'+num+'SignUserName']
				this.agree.site[i]['email'] = this.pwt['p1Daliy'+num+'SignUserEmail']
				this.agree.site[i]['date'] = this.pwt['p1Daliy'+num+'SignDatetime']
				this.agree.site[i]['img'] = this.pwt['p1Daliy'+num+'Sign'] //p1Daliy1Sign
			}
			console.log(this.agree.site,'-----------')
			// var e=new Date(this.pwt.p2SignDatetime.split(' ')[0])
			// console.log(this.pwt.p3SignDatetime)
			// this.myFunction(e)
			// this.pwt.p2SignDatetime = this.getTime(e)
			// this.pwt.p3SignDatetime = this.getTime(new Date(this.pwt.p3SignDatetime))
			// this.pwt.p4SignDatetime = this.getTime(new Date(this.pwt.p4SignDatetime))
		},
		onReachBottom(){
			console.log(11)
		},
		methods: {
			// myFunction(e){
			// var dateee = new Date(e).toJSON();
			// var date = new Date(+new Date(dateee)).toISOString().replace(/T/g,' ').replace(/\.[\d]{3}Z/,'')
			//    console.log(date)	  
			// },
			seeImg(url){
				console.log(url)
				uni.previewImage({
							current:0, 
							urls:[url] 
						})
			},
			checkWeek(indexs,index){
				console.log(indexs,index)
				var workers = this.workers
				if(workers[indexs]['checked'][index]['click']==1){
					workers[indexs]['checked'][index]['click']=0
				}else{
					workers[indexs]['checked'][index]['click']=1
				}
				this.workers = workers
			}
		},
	}
</script>

<style>
	.signsize{
		font-size: 20rpx;
	}
	.signDig{
		display: flex;
	}
	.userInfo-group{
		display: flex;
		justify-content: space-between;
		width: 100%;
	}
	.signText{
		width: 180rpx;
		margin-left: 12rpx;
	}
	.signGroup{
		/* text-align: center; */
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.signItem{
		display: flex;
		justify-content: center;
	}
	.signImg{
		width: 80rpx;
		height: auto;
	}
	.pla-num-in{
		font-size: 16rpx;
		text-align: center;
	}
	.pla-num{
		font-size: 16rpx;
		text-align: center;
	}
	.btn-text{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
		margin-left: 14rpx;
	}
	.btn-item{
		width: 100%;
		height: 100rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.btn-img{
		width: 30rpx;
		height: 30rpx;
	}
	.btn-bottom{
		display: flex;
		align-items: center;
		width: 100%;
		position: fixed;
		bottom: 0;
		left: 0;
	}
	.flex-top{
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
	}
	.picture{
		height: auto;
		width: 130rpx;
		height: 130rpx;
		margin-top: 14rpx;
	}
	.userInfo{
		width: 100%;
	}
	.user-name{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.user-date{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-top: 32rpx;
	}
	.userInfo-item{
		margin-top: 50rpx;
		display: flex;
		align-items: center;
	}
	.sign-group{
		padding-bottom: 150rpx;
	}
	.sign-item{
		margin-top: 30rpx;
		padding: 40rpx 30rpx 42rpx 30rpx;
		background-color: #FFFFFF;
	}
	.table-border{
		font-weight: bolder !important;
		border-top:1px solid #DEDFEC;
	}
	.table-group{
		border: 1px solid #DEDFEC;
		margin-top:30rpx;
		box-sizing: border-box;
	}
	.table-item{
		display: flex;
		align-items: center;
		height: 120rpx;
	}
	.table-titles{
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		border-left: 1px solid #DEDFEC;
		/* text-align: center; */
		/* width: 66rpx;
		height: 60rpx; */
		width: 400rpx;
		height: 120rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.table-tile-s{
			height: 80rpx;
			padding-left: 20rpx;
			font-size: 18rpx;
			font-family: PingFang SC;
			font-weight: 400;
			color: #232323;
			/* width: 228rpx; */
			width: 300rpx;
			display: flex;
			align-items: center;
	}
	.table-tile{
		height: 120rpx;
		padding-left: 20rpx;
	/* 	border-right: 1px solid #DEDFEC; */
		border-top: 1px solid #DEDFEC;
		font-size: 18rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		/* width: 228rpx;
		 */
		width: 300rpx;
		display: flex;
		align-items: center;
	}
	page{
		background-color: rgb(243,248,254);
	}
	.parties{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		padding-top: 22rpx;
	}
	.wokers-title{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.sel-work{
		width: 36rpx;
		height: 36rpx;
		background: #1890FF;
		border-radius: 2rpx;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-right: 10rpx;
	}
	.no-work{
		margin-right: 10rpx;
		width: 36rpx;
		height: 36rpx;
		background: #F4F4F4;
		border-radius: 2rpx;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #8B8F9E;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.wokers-group{
		margin-bottom: 30rpx;
		margin-top: 12rpx;
		display: flex;
		align-items: center;
	}
	.part-group{
		background-color: #FFFFFF;
		padding: 40rpx 30rpx 70rpx 30rpx;
	}
	.part-title{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.part-above{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-top: 22rpx;
	}
	.part-userName{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-top: 54rpx;
	}
	.part-date{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-top: 28rpx;
	}
	.part-date-item{
		margin-top: 18rpx;
		display: flex;
		align-items: center;
	}
	.part-yesr{
		width: 152rpx;
		height: 42rpx;
		background: #F4F4F4;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.part-clock{
		width: 76rpx;
		height: 42rpx;
		background: #F4F4F4;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		display: flex;
		justify-content: center;
		align-items: center;
		margin-left: 10rpx;
	}
	.part-work{
		margin-top: 62rpx;
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.part-content{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-top: 24rpx;
	}
	.task-group{
		padding: 190rpx 30rpx 30rpx 30rpx;
		background-color: #FFFFFF;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.pro-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 36rpx 30rpx;
		background-color: #F3F8FE;
	}
	.pro-name{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.pro-orderid{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.groups{
		background: ##F3F8FE;
		padding: 36rpx 30rpx 50rpx 30rpx;
	}
	.project{
		justify-content: space-between;
		align-items: center;
		display: flex;
	}
	.project-Name{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.project-hour{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.whp{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.project-date{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.state{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.process{
		width: 18rpx;
		height: 18rpx;
		border-radius: 50%;
		margin-left: 13rpx;
	}
	.colortrue{
		background-color: #22DF9B;
	}
	.colornull{
		background-color: #2FD2EA;
	}
	.colorfalse{
		background-color: #F34635;
	}
	.colorgray{
		background-color: #9095B8;
	}
	.process-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
</style>
