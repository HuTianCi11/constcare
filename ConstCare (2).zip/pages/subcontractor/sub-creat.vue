<template>
	<view class="">
		<view class="bg-white">
			<navigateBack></navigateBack>
			<view class="task-group" >
				<view class="task-name">
					{{type==1?'Create New Subcontractor':'Edit New Subcontractor'}}
				</view>
			</view>
		</view>
<!-- 		<view class="line"></view> -->
		<view class="bg-white" style="margin-top: 20rpx;">
			<view class="input-group">
				<view class="title">Information</view>
				<view class="inputName" >*UEN NO</view>
				<input type="text" class="input-class" v-model="uenNO"  value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*Company Name</view>
				<input type="text" v-model="name" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*Company Category</view>
				<view class="select-items" @click="subTypeDropDown" >
					<view class="pla-class">{{category}}</view>
					<image src="../../static/icon/down.png" class="select-img" mode="widthFix"></image>
				</view>				
				<u-select  v-model="show"  mode="single-column" :list="list"  @confirm="confirm"></u-select>
				<view class="inputName">Company Profile</view>
				<view class="">
					<textarea class="tarea" v-model="profile" value="" placeholder="Please Input" placeholder-class="tarea-pla" />
				</view>
			</view>
		</view>
<!-- 		<view class="line"></view> -->
		<view class="bg-white" style="margin-top: 20rpx;">
			<view class="input-group">
				<view class="title">Contact Person</view>
				<view class="inputName">*Contact Person</view>
				<input type="text" v-model="person" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*Mobile Phone Number</view>
				<input type="text" v-model="phone" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*Email</view>
				<input type="text" v-model="email" style="margin-bottom: 18rpx;" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="tip-item">
					<image src="../../static/icon/Warning@3x.png" mode="widthFix" class="tip-img"></image>
					<view class="tip">
						The password will be sent to your email
					</view>
				</view>
			</view>
		</view>
		<view class="save-pd">
			<view class="save" @click="create">
				<image src="../../static/icon/Save@3x.png" mode="widthFix" class="save-img"></image>
				<view class="save-text">
					Save
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	const app = getApp()
	import navigateBack from '../../components/navigateBack.vue'
	export default {
		components:{navigateBack},
		data() {
			return {
				type:1,// 1 creat  2 edit
				show:false,
				uenNO:"",
				name:"",
				category:"Please Selete Item",
				profile:"",
				person:"",
				phone:"",
				email:"",
				createMinId:'',
				subId:"",
				list: [
					{
						value: 'Concrete',
						label: 'Concrete'
					},
					{
						value: 'HVAC',
						label: 'HVAC'
					},
					{
						value: 'Masonry & Tile-Setting',
						label: 'Masonry & Tile-Setting'
					},
					{
						value: 'Roof',
						label: 'Roof'
					},
					{
						value: 'Electrical',
						label: 'Electrical'
					},
					{
						value: 'Plumbing',
						label: 'Plumbing'
					},
					{
						value: 'Special Trade',
						label: 'Special Trade'
					},
					{
						value: 'Others',
						label: 'Others'
					},
				],
			}
		},
		onLoad(opt) {
			this.type = opt.type
			if(this.type==2){
				var data=JSON.parse(opt.data).sub
				console.log(data)
				this.uenNO = data.uenNo
				this.name = data.name
				this.category = data.companyCategory
				this.profile = data.companyProfile
				this.person = data.contactPerson
				this.phone = data.mobilePhone
				this.email = data.email
				this.subId = data.id
			}
		},
		methods: {
			async subTypeDropDown(){
				const res = await this.$myReuqest({
					url:'sub/subTypeDropDown/',
					method:"GET",
					header:{'content-type': 'application/x-www-form-urlencoded'},
					hidden:true
				})
				console.log(res)
				if(res.code==200){
					this.show=true
					var list = []
					for(let i=0;i<res.data.length;i++){
						let dic = {}
						dic['label'] = res.data[i]['companyType']
						dic['value'] = res.data[i]['companyType']
						list.push(dic)
					}
					this.list = list
				}
			},
			confirm(e) {
				this.category = e[0].label
			},
			create(){
				if(this.uenNO==''||this.name==''||this.category==''||this.person==''||this.phone==''||this.email==''){
					uni.showToast({
						title:"Please Input",
						icon:"none"
					})
				}else if(!this.validateUEN(this.uenNO)){
					uni.showToast({
						title:"UEN error",
						icon:"none"
					})
				}else{
					var url
					if(this.type==1){
						url='sub/creatSub/'
					}else{
						url='sub/updateSub'
					}
					this.save(url)
				}
			},
			async save(url){
				var that = this
				var inputPhone  = this.phone
				inputPhone = inputPhone.replace('-','')
				console.log(inputPhone)
				if(isNaN(Number(inputPhone))){
					uni.showToast({
						title:'Incorrect format of mobile phone number',
						icon:'none'
					})
					return
				}
				var data={
					  "companyCategory": that.category,
					  "companyProfile": that.profile,
					  "contactPerson": that.person,
					  "email": that.email,
					  "mobilePhone": that.phone,
					  "name": that.name,
					  "uenNo": that.uenNO,
					  'createMinId':app.globalData.minId
					}
				if(url=='sub/updateSub'){
					url = url+"?minId="+app.globalData.minId 
					data['id']=this.subId
				}
				console.log(url)
				const res = await this.$myReuqest({
					url:url,
					method:"POST",
					data:data
				})
				console.log(res)
				if(res.code==200){
					uni.showToast({
						title:res.msg,
						duration:2000
					})
					setTimeout(()=>{
						uni.redirectTo({
							url:"/pages/index/index?index=0"
						})
					},2000)
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none',
					})
				}
				
				
			},
			validateUEN (uen) {
			    var debug = true;
			    const entityTypeIndicator = [
			        'LP', 'LL', 'FC', 'PF', 'RF', 'MQ', 'MM', 'NB', 'CC', 'CS', 'MB', 'FM', 'GS', 'GA',
			        'GB', 'DP', 'CP', 'NR', 'CM', 'CD', 'MD', 'HS', 'VH', 'CH', 'MH', 'CL', 'XL', 'CX',
			        'RP', 'TU', 'TC', 'FB', 'FN', 'PA', 'PB', 'SS', 'MC', 'SM'
			    ];
			
			    if (debug) {
			        console.log('(A) Businesses registered with ACRA');
			        console.log('(B) Local companies registered with ACRA');
			        console.log('(C) All other entities which will be issued new UEN');
			    }
			
			    // check that uen is not empty
			    if (!uen || String(uen) === '') {
			        if (debug) { console.log('UEN is empty'); }
			        return false;
			    }
			
			    // check if uen is 9 or 10 digits
			    if (uen.length < 9 || uen.length > 10) {
			        if (debug) { console.log('UEN is not 9 or 10 digits'); }
			        return false;
			    }
			
			    uen = uen.toUpperCase();
			    var uenStrArray = uen.split('');
			
			    // (A) Businesses registered with ACRA
			    if (uenStrArray.length === 9) {
			        // check that last character is a letter
			        if (!isNaN(uenStrArray[uenStrArray.length - 1])) {
			            if (debug) { console.log('(A) last character is not an alphabet'); }
			            return false;
			        }
			
			        for (var i = 0; i < uenStrArray.length - 1; i++) {
			            // check that first 8 letters are all numbers
			            if (isNaN(uenStrArray[i])) {
			                if (debug) { console.log('(A) there are non-numbers in 1st to 8th letters'); }
			                return false;
			            }
			        }
			
			        // (A) Businesses registered with ACRA (SUCCESS)
			        if (debug) { console.log('valid (A) Businesses registered with ACRA'); }
			        return true;
			    }
			    else if (uenStrArray.length === 10) {
			        // check that last character is a letter
			        if (!isNaN(uenStrArray[uenStrArray.length - 1])) {
			            if (debug) { console.log('(B)(C) last character is not an alphabet'); }
			            return false;
			        }
			
			        // (B) Local companies registered with ACRA
			        if (!isNaN(uenStrArray[0]) && !isNaN(uenStrArray[1]) && !isNaN(uenStrArray[2]) && !isNaN(uenStrArray[3])) {
			            // check that 5th to 9th letters are all numbers
			            if (!isNaN(uenStrArray[4]) && !isNaN(uenStrArray[5]) && !isNaN(uenStrArray[6]) &&
			                !isNaN(uenStrArray[7]) && !isNaN(uenStrArray[8])) {
			                // (B) Local companies registered with ACRA (SUCCESS)
			                if (debug) { console.log('valid (B) Local companies registered with ACRA'); }
			                return true;
			            } else {
			                if (debug) { console.log('(B) there are non-numbers in 5th to 9th letters'); }
			                return false;
			            }
			        }
			        // (C) All other entities which will be issued new UEN
			        else {
			            // check that 1st letter is either T or S or R
			            if (uenStrArray[0] !== 'T' && uenStrArray[0] !== 'S' && uenStrArray[0] !== 'R') {
			                if (debug) { console.log('(C) 1st letter is incorrect'); }
			                return false;
			            }
			
			            // check that 2nd and 3rd letters are numbers only
			            if (isNaN(uenStrArray[1]) || isNaN(uenStrArray[2])) {
			                if (debug) { console.log('(C) 2nd and 3rd letter is incorrect'); }
			                return false;
			            }
			
			            // check that 4th letter is an alphabet
			            if (!isNaN(uenStrArray[3])) {
			                if (debug) { console.log('(C) 4th letter is not an alphabet'); }
			                return false;
			            }
			
			            // check entity-type indicator
			            var entityTypeMatch = false,
			                entityType = String(uenStrArray[3]) + String(uenStrArray[4]);
			            for (var i = 0; i < entityTypeIndicator.length; i++) {
			                if (String(entityTypeIndicator[i]) === String(entityType)) {
			                    entityTypeMatch = true;
			                }
			            }
			            if (!entityTypeMatch) {
			                if (debug) { console.log('(C) entity-type indicator is invalid'); }
			                return false;
			            }
			
			            // check that 6th to 9th letters are numbers only
			            if (isNaN(uenStrArray[5]) || isNaN(uenStrArray[6]) || isNaN(uenStrArray[7]) || isNaN(uenStrArray[8])) {
			                if (debug) { console.log('(C) 2nd and 3rd letter is incorrect'); }
			                return false;
			            }
			
			            // (C) All other entities which will be issued new UEN (SUCCESS)
			            if (debug) { console.log('valid (C) All other entities which will be issued new UEN'); }
			            return true;
			        }
			    }
			
			    return false;
			}
		},
	}
</script>

<style>
	.save-pd{
		padding-bottom: 156rpx;
		margin-left: 30rpx;
	}
	.save{
		margin-top: 60rpx;
		width: 260rpx;
		height: 70rpx;
		background: #1890FF;
		border-radius: 5rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.save-img{
		width: 22rpx;
		height: 22rpx;
		margin-right: 10rpx;
	}
	.save-text{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.content{padding:20rpx 30rpx 0 30rpx;display: flex;justify-content: space-between;align-items: center;}
	.task-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding:200rpx 30rpx 30rpx 30rpx;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	page{
		background-color: rgb(243,248,254);
	}
/* 	.line{
		height: 20rpx;
		background-color: rgb(243,248,254);
	} */
	.input-group{
		padding: 42rpx 30rpx;
	}
	.title{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 50rpx;
	}
	.inputName{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 16rpx;
	}
	.input-class,.select-items{
		height: 70rpx;
		background: #FFFFFF;
		border: 1px solid #DEDFEC;
		border-radius: 5rpx;
		margin-bottom: 50rpx;
		padding: 0 20rpx;
	}
	.select-items{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.select-img{
		width: 36rpx;
		height: auto;
	}
	.tarea-pla{
		padding: 10rpx;
	}
	.pla-class,.tarea-pla{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.tarea{
		margin-bottom: 50rpx;
	/* 	width: 100%; */
		width: 660rpx;
		padding: 15rpx;
		height: 170px;
		background: #FFFFFF;
		border: 1px solid #DEDFEC;
		border-radius: 5px;
	}
	.tip-item{
		display: flex;
		height: 80rpx;
	}
	.tip{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #E74A3B;
		margin-top: 1rpx;
		padding-bottom: 20rpx;
	}
	.tip-img{
		padding-top: 6rpx;
		width: 36rpx;
		height: auto;
		margin-right: 10rpx;
	}
	.bg-white{
		background-color: #FFFFFF;
	}
</style>
