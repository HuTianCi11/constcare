<template>
	<view class="">
		<view class="back-group">
			<view class="back-item">
				<image src="/static/icon/back.png" mode="widthFix" class="back" @click="back"></image>
				<view class="dispatch">
					<image src="/static/icon/Sign@3x.png" class="nav-img" style="margin-right: 40rpx;" mode="widthFix" @click="edit"></image>
					<image src="/static/icon/delete@3x.png" class="nav-img" mode="widthFix"  @click="showModal"></image>
				</view>
			</view>
		</view>
		<u-modal v-model="show" @confirm="delSub" confirm-text='Yes' cancel-text='No' title='Tips' content='Confirm to delete?' ref="uModal" ></u-modal>
		<view class="introduce">
			<view class="title">{{item.sub.name}}</view>
			<view class="introduce-item">
				<view class="intr">
					<view class="intr-num">{{item.taskNum}}<text class="intr-word">Task</text></view>
					<view style="margin-left: 90rpx;" class="intr-num">{{item.workerNum}}<text class="intr-word">Woker</text></view>
				</view>
				<view class="uen">UEN NO :{{item.sub.uenNo}}</view>
			</view>
		</view>
		<view class="detail">Detail</view>
		<view class="Information-group">
			<view class="info-title">Information</view>
			<view class="info-items">
				<view class="info-name">Company Category</view>
				<text class="info-content">{{item.sub.companyCategory}}</text>
			</view>
			<view class="info-items">
				<view class="info-name" style="min-width: 200rpx;">Company Profile</view>
				<view class="info-content" style="word-break: break-word;">{{item.sub.companyProfile}}</view>
			</view>
			<view class="info-title" style="margin-top: 90rpx;">Contact Person</view>
			<view class="info-items">
				<view class="info-name">Contact Person</view>
				<text class="info-content">{{item.sub.contactPerson}}</text>
			</view>
			<view class="info-items">
				<view class="info-name">Mobile Phone Number</view>
				<text class="info-content">{{item.sub.mobilePhone}}</text>
			</view>
			<view class="info-items">
				<view class="info-name">Email</view>
				<text class="info-content">{{item.sub.email}}</text>
			</view>
		</view>
		<view class="detail" v-if="taskList.length>0">Task List</view>
		<view class="list-group" >
			<view :class="index<3-1?'btm-border':''" class="Information-group" v-for="(task,index) in taskList" >
				<view class="task-item">
					<view class="task-name">{{task.conName}}</view>
					<view class="task-days">{{task.totalWorkingHours}} days</view>
				</view>
				<view class="task-item">
					<view class="">
						<view class="siteName">{{task.name}}</view>
						<view class="date">{{task.startDate}} ~{{task.endDate}} </view>
					</view>
					<view class="persent-s">
						<view class="persent">{{task.percent}}%</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				subId:"",
				item:"",
				taskList:[],
				show:false
			}
		},
		onLoad(opt) {
			this.subId = opt.id
			this.selectSub(this.subId)
			this.subTaskList(this.subId)
		},
		methods: {
			edit(){
					uni.navigateTo({
						url:"./sub-creat?type=2&data="+JSON.stringify(this.item)
					})
			},
			showModal(){
					this.show=true
			},
			async delSub(){
				console.log(111)
				var that = this
				const res = await this.$myReuqest({
					url:'sub/delSub/',
					method:"GET",
					header:{'content-type': 'application/x-www-form-urlencoded'},
					data:{
						minId:app.globalData.minId,
						subId:this.subId
					},
				})
				console.log(res)
				if(res.code==200){
					uni.showToast({
						title:res.msg,
						duration:2000
					})
					setTimeout(()=>{
						uni.navigateBack({
							delta:1
						})
					},2000)
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none',
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			async selectSub(subId){
				var that = this
				const res = await this.$myReuqest({
					url:'sub/selectSub/',
					method:"POST",
					header:{'content-type': 'application/x-www-form-urlencoded'},
					data:{
						subId
					},
				})
				if(res.code==200){
					that.item = res.data
				}else{
					uni.showToast({
						title:"Network Error",
						icon:'none'
					})
				}
			},
			async subTaskList(subId){
				var that = this
				const res = await this.$myReuqest({
					url:'task/subTaskList/',
					method:"GET",
					data:{
						subId
					},
				})
				console.log(res,"子包任务")
				if(res.code==200){
					if(res.data){
						for(let i=0;i<res.data.length;i++){
							let num = parseInt(res.data[i].percent*100)
							if(num>100){
								num=100
							}
							res.data[i].percent = num
						}
						that.taskList = res.data
					}
					
				}else{
					uni.showToast({
						title:"Network Error",
						icon:'none'
					})
				}
			}
		},
	}
</script>

<style>
	.btm-border{
		border-bottom: 1px solid #DEDFEC
	}
	.persent-s{
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		
	}
	.siteName{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-top: 20rpx;
	}
	.date{
		padding-top: 45rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
	}
	.persent{
		width: 75rpx;
		height: 75rpx;
		background: #FAFBFF;
		border-radius: 50%;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.task-item{
		display: flex;
		justify-content: space-between;
	}
	.task-name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
	}
	.task-days{
		width: 129rpx;
		height: 40rpx;
		border: 1rpx solid #1B91FF;
		border-radius: 20rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #1B91FF;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.info-items{
		display: flex;
/* 		align-items: center; */
		margin-bottom: 36rpx;
	}
	.info-name{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.info-content{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 30rpx;
	}
	.info-title{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		padding-bottom: 40rpx;
		border-bottom: 1px solid #DEDFEC;
		margin-bottom: 30rpx;
	}
	.Information-group{
		background-color: #FFFFFF;
		padding: 42rpx 30rpx;
	}
	.list-group{
		padding-bottom: 200rpx;
	}
	page{
		background-color: rgb(243,248,254);
	}
	.back-group{
		background-color: #FFFFFF;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		padding-top: 80rpx;
	}
	.back-item{
		padding: 20rpx  30rpx 20rpx 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.dispatch{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.back{
		width: 40rpx;
		height: auto;
	}
	.nav-img{width: 35rpx;}
	.introduce{
		padding: 0 30rpx;
		padding-top: 208rpx;
		background-color: #FFFFFF;
	}
	.title{
		font-size: 36rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.introduce-item,.intr{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.introduce-item{
		margin-top: 52rpx;
		padding-bottom: 30rpx;
	}
	.intr-num{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.intr-word{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 6rpx;
	}
	.uen{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		width: 233rpx;
		height: 44rpx;
		background: #FAFBFF;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.detail{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
		padding: 60rpx 30rpx 30rpx 30rpx;
	}
</style>
