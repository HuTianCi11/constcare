<template>
	<view class="">
		<view class="back-group">
			<view class="back-item">
				<image src="../../static/icon/back.png" mode="widthFix" class="back" @click="back"></image>
			</view>
		</view>
		<view class="task-group" >
			<view class="task-name">
				{{content.conName}}
			</view>
			<view class="percent">
				{{content.percent}}%
			</view>
		</view>
		<view class="construction">
			<view class="site-Name">
				{{content.name}}
			</view>
			<view class="wokers">
				<view class="">
					<text class="workNum">{{content.subNum}}</text><text class="workword">Sub</text> 
				</view>
				<view class="">
					<text class="workNum" >{{content.workNum}}</text><text  class="workword">Woker</text>
				</view>
				<view class="">
					<text class="workNum">{{content.endDay}}</text><text class="workword">Current Total Working</text> 
				</view>
			</view>
		</view>
		<view class="date">
			<view class="date-item">
				<view class="date-time">{{content.startDate}}</view>
				<view class="date-tip">Start Date</view>
			</view>
			<view class="line"></view>
			<view class="date-item">
				<view class="date-time">{{content.endDate}}</view>
				<view class="date-tip">End Date</view>
			</view>
			<view class="line"></view>
			<view class="date-item">
				<view class="date-time">{{content.totalWorkingHours}} days</view>
				<view class="date-tip">Total Working</view>
			</view>
		</view>
		<view class="timeline">
			<view class="calendar">
				<view class="calendar-name" v-if="items.length>0">Subcontractors</view>
			</view>
			<view class="sub-group" v-for="(item,index) in items">
				<view class="">
					<view class="sub-name">{{item.name}}</view>
					<view class="sub-content">*Start Date<text class="sub-text">{{item.startDate}}</text></view>
					<view class="sub-content">*End Date<text class="sub-text">{{item.endDate}}</text></view>
					<view class="sub-content">Total Working Hours<text class="sub-text">{{item.totalWorkingHours}} days</text></view>
					<view class="sub-content">Worker Count<text class="sub-text">{{item.subWorkNum}} people</text></view>
				</view>
				<view class="sub-right">
					<view class="sub-percent">{{item.percent}}%</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				taskId:'',
				content:"",
				items:''
			}
		},
		onLoad(opt) {
			console.log(opt)
			this.taskId = opt.taskId
			this.taskInfo(this.taskId)
			this.taskInfoSubList(this.taskId)

		},
		methods: {
			async taskInfoSubList(taskId){
				var that = this
				const res = await this.$myReuqest({
					url:'task/taskInfoSubList/',
					method:"GET",
					data:{
						taskId:taskId
					}
				})
				console.log(res,'null')
				if(res.code==200){
					if(res.data){
						for(let i=0;i<res.data.length;i++){
							let num =parseInt(res.data[i].percent*100)
							if(num>100){
								num=100
							}
							res.data[i].percent = num
						}
						this.items = res.data
						
					}
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			async taskInfo(taskId){
				var that = this
				const res = await this.$myReuqest({
					url:'task/taskInfo/',
					method:"GET",
					data:{
						id:taskId
					}
				})
				console.log(res)
				if(res.code==200){
					let num =parseInt(res.data.percent*100)
					if(num>100){
						num=100
					}
					res.data.percent = num
					this.content = res.data
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			dispatch(){
				uni.navigateTo({
					url:'./task-dispatch'
				})
			}
		},
	}
</script>

<style>
	.sub-text{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 30rpx;
	}
	.sub-group{
		margin-top: 20rpx;
		display: flex;
		justify-content: space-between;
		padding: 33rpx 18rpx 55rpx 18rpx;
		border: 1rpx solid #DEDFEC;
	}
	.sub-right{
		display: flex;
		flex-direction: column;
		justify-content: start;
		height: 100%;
	}
	.sub-percent{
		width: 90rpx;
		height: 90rpx;
		border: 1rpx solid #1890FF;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #1B92FF;
	}
	.sub-content{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-top: 40rpx;
	}
	.sub-name{
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
	}
	.back-group{
		background-color: #FFFFFF;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		padding-top: 80rpx;
	}
	.back-item{
		padding: 20rpx  30rpx 20rpx 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.dispatch{
		display: flex;
		justify-content: center;
		align-items: center;
		width: 158rpx;
		height: 50rpx;
		background: #1890FF;
		border-radius: 25rpx;
		color: #FFFFFF;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.back{
		width: 40rpx;
		height: auto;
	}
	.dispatch-img{
		width: 23rpx;
		height: 23rpx;
		margin-right: 5rpx;
	}
	.task-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 190rpx 30rpx 30rpx 30rpx;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.percent{
		width: 90rpx;
		height: 90rpx;
		background: #14D6AF;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #FFFFFF;
		font-size: 20rpx;
		font-family: PingFang SC;
	}
	.construction{
		padding: 0 30rpx;
	}
	.site-Name{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.wokers{
		display: flex;
		justify-content: space-between;
		margin-top: 50rpx;
	}
	.workNum{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.workword{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 10rpx;
	}
	.date{
		margin-top: 40rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding:56rpx  68rpx 42rpx 68rpx;
		background-color: rgb(243,248,254);
	}
	.line{
		width: 1rpx;
		height: 58rpx;
		background: #DEDFEC;
	}
	.date-item{
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}
	.date-time{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.date-tip{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-top: 16rpx;
	}
	.calendar-icon{
		width: 26rpx;height: auto;margin-top: 1rpx;
	}
	.calendar{
		display: flex;
		justify-content: space-between;
		margin-top: 40rpx;
	}
	.calendar-item{
		display: flex;
		align-items: center;
	}
	.calendar-date{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-right: 30rpx;
	}
	.calendar-name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 15rpx;
	}
	.timeline{
		margin: 0 30rpx;
		padding-bottom: 100rpx;
	}
	.info-img{
		width: 34rpx;
		height: 34rpx;
		margin-left: 10rpx;
	}
	.userInfo,.info{
		display: flex;
		align-items: center;
	}
	.workers{
		border: 1rpx solid #DEDFEC;
		padding: 24rpx 30rpx 40rpx 20rpx;
		margin-bottom: 30rpx;
	}
	.userInfo{
		justify-content: space-between;
	}
	.info-name{
		margin-right: 8rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.day{font-size: 30rpx;font-family: PingFang SC;font-weight: 400;color: #232323;}
	.month{font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #585B66;}
	.year{font-size: 20rpx;font-family: PingFang SC;font-weight: 400;color: #8B8F9E;text-align: end;}
	.work-text{display: flex;align-items: center;}
	.finNum{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.cardId{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 40rpx;
	}
	.orderNum{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-left: 20rpx;
	}
</style>
