<template>
	<view class="">
		<view class="back-group">
			<view class="back-item">
				<image src="../../static/icon/back.png" mode="widthFix" class="back" @click="back"></image>
				<view class="dispatch" v-if="dispatchShow">
					<image src="../../static/icon/Dispatch@3x.png" class="dispatch-img"></image>
					<view class="dispatch-text"   @click="dispatch">Dispatch</view>
				</view>
			</view>
		</view>
		<view class="task-group" >
			<view class="task-name">
				{{content.conName}}
			</view>
			<view class="percent">
				{{content.percent}}%
			</view>
		</view>
		<view class="construction">
			<view class="site-Name">
				Construction Site Name
			</view>
			<view class="wokers">
				<text class="workNum">{{content.workNum}}</text><text class="workword">Woker</text> <text class="workNum" style="margin-left: 114rpx;">{{content.endDay}}</text><text  class="workword">Current Total working</text>
			</view>
		</view>
		<view class="date">
			<view class="date-item">
				<view class="date-time">{{content.start}}</view>
				<view class="date-tip">Start Date</view>
			</view>
			<view class="line"></view>
			<view class="date-item">
				<view class="date-time">{{content.end}}</view>
				<view class="date-tip">End Date</view>
			</view>
			<view class="line"></view>
			<view class="date-item">
				<view class="date-time">{{content.countDay}} days</view>
				<view class="date-tip">Total Working</view>
			</view>
		</view>
		<view class="timeline">
			<view class="calendar">
				<view class="calendar-name">Worker Timeline</view>
				<view class="calendar-item" @click="show=true">
					<view class="calendar-date">{{nowDate}}</view>
					<image src="../../static/icon/calendar@3x.png" class="calendar-icon" mode="widthFix"></image>
				</view>
			</view>
			<u-picker v-model="show" mode="time" @confirm='confirm'></u-picker>
			<view class="" style="padding-bottom: 60rpx;">
				<view class="workers" v-for="(item,index) in list">
					<view class="userInfo">
						<view class="info">
							<view class="info-name">{{item.userName}}</view>
							<!-- <image src="../../static/icon/sex_boy.png" class="info-img"  ></image>
							<image src="../../static/icon/Singapore@3x.png" class="info-img" ></image> -->
							<view class="county">{{item.nationality}}</view>
						</view>
						<view class="time">
							<view class="day">{{item.day}}<text class="month">/{{item.mon}}</text></view>
							<view class="year">{{item.year}}</view>
						</view>
					</view>
					<view class="work-text">
						<view class="finNum">FIN Numbe</view>
						<view class="orderNum">{{item.finNumber}}</view>
						<view class="cardId">Safety Card Id</view>
						<view class="orderNum">{{item.safetyCardId}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				content:"",
				list:"",
				nowDate:"",
				show:false,
				dispatchShow:false
			}
		},
		onLoad(opt) {
			var manager = uni.getStorageSync('manager');
			for(let i=0;i<manager.length;i++){
				if(manager[i]==32){
					this.dispatchShow=true
					break
				}
			}
			this.nowDate = this.getTime()
			console.log(opt)
			this.taskId = opt.taskId
			// this.appSubTaskInfo(this.taskId)
		},
		onShow(){
			this.appSubTaskInfo(this.taskId)
			this.selectWorksBySubTaskId(this.taskId)
		},
		methods: {
			confirm(e){
				this.nowDate = e.year+'-'+e.month+'-'+e.day
				// console.log(this.nowDate)
				this.selectWorksBySubTaskId(this.taskId)
				
			},
			async appSubTaskInfo(taskId){
				var that = this
				const res = await this.$myReuqest({
					url:'task/appSubTaskInfo',
					method:"GET",
					data:{
						subId:app.globalData.subId,
						taskId:taskId
					},
					header:{'content-type': 'application/x-www-form-urlencoded'},
					hidden:true
				})
				console.log(res,'任务信息')
				console.log(app.globalData.subId,
						taskId)
				if(res.code==200){
					// var percent = parseFloat(res.data.percent*100).toString()
					// percent = percent.split('.')[0]
					var percent = parseInt(res.data.percent*100)
					if(percent>100){
						percent=100
					}
					res.data.percent = percent
					this.content = res.data
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			async selectWorksBySubTaskId(taskId){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/selectWorksBySubTaskId/',
					method:"POST",
					data:{
					  "reqTime":this.nowDate,
					  "subId": app.globalData.subId,
					  "taskId": parseInt(taskId)
					},
					hidden:true
				})
				// var test ={
				// 	  "reqTime":this.nowDate,
				// 	  "subId": app.globalData.subId,
				// 	  "taskId": parseInt(taskId)
				// 	}
				// console.log(test)
				console.log(res,'工人时间线')
				if(res.code==200){
					if(res.data){
						for(let i=0;i<res.data.list.length;i++){
							var date = res.data.list[i].data.split("-")
							res.data.list[i].day  = date[2]
							res.data.list[i].mon  = date[1]
							res.data.list[i].year  = date[0]
						}
						this.list = res.data.list
					}else{
						this.list =[]
					}
					
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			dispatch(){
				uni.navigateTo({
					url:'./task-dispatch?taskId='+this.taskId
				})
			},
			getTime(){
				//获取当前时间
				var date = new Date();
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				var day = date.getDate();
				if (month < 10) {
				    month = "0" + month;
				}
				if (day < 10) {
				    day = "0" + day;
				}
				var nowDate = year + "-" + month + "-" + day;
				return nowDate
			}
		},
	}
</script>

<style>
	.county{
		margin-left: 20rpx;
		font-size: 22rpx;
	}
	.back-group{
		background-color: #FFFFFF;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		padding-top: 80rpx;
	}
	.back-item{
		padding: 20rpx  30rpx 20rpx 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.dispatch{
		display: flex;
		justify-content: center;
		align-items: center;
		width: 158rpx;
		height: 50rpx;
		background: #1890FF;
		border-radius: 25rpx;
		color: #FFFFFF;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.back{
		width: 40rpx;
		height: auto;
	}
	.dispatch-img{
		width: 23rpx;
		height: 23rpx;
		margin-right: 5rpx;
	}
	.task-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 190rpx 30rpx 30rpx 30rpx;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.percent{
		width: 90rpx;
		height: 90rpx;
		background: #14D6AF;
		border-radius: 50%;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #FFFFFF;
		font-size: 20rpx;
		font-family: PingFang SC;
	}
	.construction{
		padding: 0 30rpx;
	}
	.site-Name{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.wokers{
		margin-top: 50rpx;
	}
	.workNum{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.workword{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 10rpx;
	}
	.date{
		margin-top: 40rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding:56rpx  68rpx 42rpx 68rpx;
		background-color: rgb(243,248,254);
	}
	.line{
		width: 1rpx;
		height: 58rpx;
		background: #DEDFEC;
	}
	.date-item{
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
	}
	.date-time{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.date-tip{
		font-size: 22rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-top: 16rpx;
	}
	.calendar-icon{
		width: 26rpx;height: auto;margin-top: 1rpx;
	}
	.calendar{
		display: flex;
		justify-content: space-between;
		margin-top: 40rpx;
	}
	.calendar-item{
		display: flex;
		align-items: center;
	}
	.calendar-date{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-right: 30rpx;
	}
	.calendar-name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 40rpx;
	}
	.timeline{
		margin: 0 30rpx;
	}
	.info-img{
		width: 34rpx;
		height: 34rpx;
		margin-left: 10rpx;
	}
	.userInfo,.info{
		display: flex;
		align-items: center;
	}
	.workers{
		border: 1rpx solid #DEDFEC;
		padding: 24rpx 30rpx 40rpx 20rpx;
		margin-bottom: 30rpx;
	}
	.userInfo{
		justify-content: space-between;
	}
	.info-name{
		margin-right: 8rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.day{font-size: 30rpx;font-family: PingFang SC;font-weight: 400;color: #232323;}
	.month{font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #585B66;}
	.year{font-size: 20rpx;font-family: PingFang SC;font-weight: 400;color: #8B8F9E;text-align: end;}
	.work-text{display: flex;align-items: center;}
	.finNum{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.cardId{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 40rpx;
	}
	.orderNum{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-left: 20rpx;
	}
</style>
