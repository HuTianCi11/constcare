<template>
	<view class="">
		<navigateBack></navigateBack>
		<view class="task-group" >
			<view class="task-name">
				Select Worker
			</view>
			<view class="time">
				<view class="day">{{day}}<text class="month">/{{month}}</text></view>
				<view class="year">{{year}}</view>
			</view>
		</view>
		<view class="site-Name">
			Please check the information of the workers to 
			be dispatched
		</view>
		<view class="line"></view>
		<view class="result">
			Last Result
		</view>
		<view class="timeline">
			<view class="workers" :class="item.checked?'yes':'no'" v-for="(item,index) in content">
				<view class="last-result">
					<view class="userInfo">
						<view class="info">
							<view class="info-name">{{item.username}}</view>
							<view class="county">{{item.nationality}}</view>
							<!-- <image src="../../static/icon/sex_boy.png" class="info-img"  ></image>
							<image src="../../static/icon/Singapore@3x.png" class="info-img" ></image> -->
						</view>
					</view>
					<view class="work-text">
						<view class="finNum">FIN Numbe</view>
						<view class="orderNum">{{item.finNumber}}</view>
						<view class="cardId">Safety Card Id</view>
						<view class="orderNum">{{item.safetyCardId}}</view>
					</view>
				</view>
				<view class="select-items">
				<!-- 	<checkbox  :value="item.id" :checked="item.checked"  /> -->
				<u-checkbox 
							@change="checkboxChange" 
							v-model="item.checked" 
							:name="index"
						>{{item.name}}</u-checkbox>
					<view class="select-text">Select</view>
				</view>
			</view>
		</view>
		<!-- save button bottom -->	
		<view class="save" @click="dispatch">
			<image src="../../static/icon/Save@3x.png" class="save-img" ></image>
			<view class="save-text">
				Save
			</view>
		</view>
	</view>
</template>

<script>
	const app = getApp()
	import navigateBack from '../../components/navigateBack.vue'
	export default {
		components:{navigateBack},
		data() {
			return {
				year:"",
				month:"",
				day:"",
				content:"",
				taskId:""
			}
		},
		onLoad(opt) {
			this.taskId = opt.taskId
			this.getTime()
			this.freeWorker()
			
		},
		methods: {
			checkboxChange: function (e) {
				console.log(this.content)
			},
			//派遣工人
			async dispatch(){
				var that = this
				var loginData = uni.getStorageSync('loginData')
				var workIds =[]
				for(let i=0;i<this.content.length;i++){
					if(this.content[i].checked){
						workIds.push(this.content[i].id)
					}
					
				}
				const res = await this.$myReuqest({
					url:'worker/dispatch/',
					method:"POST",
					data:{
						subId:app.globalData.subId,
						taskId:this.taskId,
						userId:loginData.id,
						workIds: workIds.join(',')
					},
					header:{'content-type': 'application/x-www-form-urlencoded'}
				})
				console.log(res)
				if(res.code==200){
					var list = []
					for(let i=0;i<this.content.length;i++){
						if(this.content[i]['checked']==false){
							list.push(this.content[i])
						}
					}
					this.content = list
					uni.showToast({
						title:res.msg,
						duration:1500
					})
					setTimeout(()=>{
						uni.navigateBack({
							delta:1
						})
					},1500)
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			async freeWorker(){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/freeWorker/',
					method:"POST",
					data:{
						id:app.globalData.subId,
					},
					header:{'content-type': 'application/x-www-form-urlencoded'}
				})
				console.log(res)
				if(res.code==200){
					for(let i=0;i<res.data.length;i++){
						res.data[i]['checked']=false
					}
					this.content = res.data
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			getTime(){
				//获取当前时间
				var date = new Date();
				var year = date.getFullYear();
				var month = date.getMonth() + 1;
				var day = date.getDate();
				if (month < 10) {
				    month = "0" + month;
				}
				if (day < 10) {
				    day = "0" + day;
				}
				this.year = year 
				this.month = month
				this.day = day
				// var nowDate = year + "-" + month + "-" + day;
				// return nowDate
			}
		},
	}
</script>

<style>
	.county{
		margin-left: 20rpx;
		font-size: 22rpx;
	}
	.save{
		position: fixed;
		bottom: 0;left: 0;
		height: 100rpx;
		width: 100%;
		background: #1890FF;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.save-img{
		width: 26rpx;
		height: 26rpx;
		margin-right: 10rpx;
	}
	.save-text{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.content{padding: 0 30rpx;display: flex;justify-content: space-between;align-items: center;margin-top: 20rpx;}
	.back{
		width: 40rpx;
		height: auto;
	}
	.task-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 190rpx 30rpx 30rpx 30rpx;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.site-Name{
		width: 524rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		padding: 0 30rpx;
		margin-bottom: 34rpx;
	}
	.line{
		height: 20rpx;
		background-color: rgb(243,248,254);
	}
	.result{
		padding: 40rpx 0rpx 30rpx 30rpx;
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #1890FF;
	}

	.timeline{
		margin: 0 30rpx;
		padding-bottom: 142rpx;
	}
	.info-img{
		width: 34rpx;
		height: 34rpx;
		margin-left: 10rpx;
	}
	.userInfo,.info{
		display: flex;
		align-items: center;
	}
	.yes{
		border: 1rpx solid #1890FF;
		background-color: #F0F8FF;
	}
	.no{
		border: 1rpx solid #DEDFEC;
	}
	.workers{
		padding: 30rpx 30rpx 36rpx 20rpx;
		margin-bottom: 30rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.select-items{
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column;
	}
	.select-text{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-top: 14rpx;
	}
	.userInfo{
		justify-content: space-between;
	}
	.info-name{
		margin-right: 8rpx;
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
	}
	.day{font-size: 30rpx;font-family: PingFang SC;font-weight: 400;color: #17C7C5;}
	.month{font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #585B66;}
	.year{font-size: 20rpx;font-family: PingFang SC;font-weight: 400;color: #8B8F9E;text-align: end;}
	.work-text{display: flex;align-items: center;margin-top: 32rpx;}
	.finNum{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.cardId{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		margin-left: 40rpx;
	}
	.orderNum{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #585B66;
		margin-left: 20rpx;
	}
</style>
