<template>
	<view class="">
		<view class="bg-white">
			<navigateBack></navigateBack>
			<view class="task-group">
				<view class="task-name">
					{{type==1?'Create  General Work':'Edit  General Work'}}
				</view>
			</view>
		</view>
<!-- 		<view class="line"></view> -->
		<view class="bg-white" style="margin-top: 20rpx;">
			<view class="input-group">
				<view class="title">Information</view>
				<view class="inputName">*UserName</view>
				<input type="text" v-model="username" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*FIN Numbe</view>
				<input v-model="finNumber" type="text" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">*Nationality</view>
				<view class="select-items" @click="showCT">
					<view class="pla-class">{{nationality}}</view>
					<image src="../../static/icon/down.png" class="select-img" mode="widthFix"></image>
				</view>
<!-- 				<u-select  v-model="show"  mode="single-column" :list="select"  @confirm="confirm"></u-select> -->
				<u-popup v-model="show" mode="right" width='100%'>
					<scroll-view scroll-y="true" style="height: 100vh;">
						<view class="ct-group" >
							<view class="ct-input">
								<u-search placeholder="Please Input" @input='inputName' @clear="clear" v-model="cy_Name"></u-search>
							</view>
							<block v-if="cy_Name==''">
								<view v-for="(items,indexs) in indexList" :key="indexs" >
									<view class="ct-title" v-if="country[indexs][items].length>0">{{items}}</view>
									<view class="ct-item" v-for="(item,index) in country[indexs][items]" :key="index" >
										<view class="list-cell" @click="sel_country(item.Name)">{{item.Name}}</view>
									</view>
								</view>
							</block> 
							<block  v-else>
								<view v-for="(item,index) in lst" :key="index" >
									<view class="list-cell" @click="sel_country(item)">{{item}}</view>
								</view>
							</block>
							
						</view>
						
					</scroll-view>
						
				</u-popup>
				<view class="inputName">*Mobile Phone Number</view>
				<input type="text" v-model="mobilePhone" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
				<view class="inputName">Safety Card Id</view>
				<input v-model="safetyCardId" type="text" class="input-class" value="" placeholder-class="pla-class"  placeholder="Please Input"/>
			</view>
		</view>
<!-- 		<view class="line"></view> -->
		<view class="save-pd">
			<view class="save" @click="save">
				<image src="../../static/icon/Save@3x.png" mode="widthFix" class="save-img"></image>
				<view class="save-text">
					Save
				</view>
			</view>
		</view>
		
		
	
	</view>
</template>

<script>
	const app = getApp()
	import navigateBack from '../../components/navigateBack.vue'
	import countrys from '../../utils/country.js'
	export default {
		components:{navigateBack},
		data() {
			return {
				type : 1, // 1:creat 2:edit
				show:false,
				finNumber: "",
				mobilePhone: "",
				nationality: "Please Selete Item",
				safetyCardId: "",
				username: "",
				workerId:"",
				select:[
					{value:"Singapore",label:'Singapore'}
				],
				prefix:"",
				number:'',
				country:'',
				scrollTop:0,
				indexList: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U",
									"V", "W", "X", "Y", "Z"
								],
				cy_Name:"",
				ctNmaes:"",
				lst:[]
			}
		},
		onLoad(opt) {
			this.type = opt.type
			this.country = countrys.ct
			this.ctNmaes = countrys.ctName
			if(this.type==2){
				var data =JSON.parse(opt.data)
				console.log(data)
				this.finNumber = data.finNumber
				this.mobilePhone = data.mobilePhone
				this.nationality= data.nationality
				this.safetyCardId= data.safetyCardId
				this.username= data.username
				this.workerId = data.id
			}
		},
		onPageScroll(e) {
			console.log(e)
					this.scrollTop = e.scrollTop;
				},
		methods: {
			sel_country(name){
				this.nationality = name
				this.show = false
				this.cy_Name=''
			},
			clear(){
				this.cy_Name=''
				console.log(this.cy_Name,'111')
			},
			inputName(e){
				
				console.log(e)
				e=e.toUpperCase()
				console.log(e)
				this.cy_Name= e
				this.lst =[]
				for(let i=0;i<this.ctNmaes.length;i++){
					if(this.ctNmaes[i].toUpperCase().indexOf(e)!=-1){
						this.lst.push(this.ctNmaes[i])
					}
				}
				// console.log(this.lst)
				
			},
			showCT(){
				this.show=true
				console.log(111)
			},
			fin(ic) {
			    ic = ic.trim().toUpperCase();
				if(ic[0]!='F'){
					return 0;
				}
			    if (
			      !/^[S|T]\d{7}[J|Z|I|H|G|F|E|D|C|B|A]|[F|G]\d{7}[X|W|U|T|R|Q|P|N|M|L|K]$/.test(
			        ic
			      )
			    ) {
			      return 0;
			    }
			    this.prefix = ic[0].toUpperCase();
			    this.number = ic.slice(1, -1);
			    const oldChecksum = ic.slice(-1).toUpperCase();
			    return oldChecksum === this.checksum(this.prefix, this.number) ? 1 : -1;
			  },
			  stringToSum(number) {
			    const multiplyFactors = [2, 7, 6, 5, 4, 3, 2];
			    return number
			      .split('')
			      .map(s => parseInt(s))
			      .map((digit, i) => digit * multiplyFactors[i])
			      .reduce((a, b) => a + b, 0);
			  },
			 checksum(prefix, number) {
			    prefix = prefix.toUpperCase();
			    let sum = 0;
			    if (prefix === 'T' || prefix === 'G') sum = 4; // an offset if start with T/G
			    sum += this.stringToSum(number);
				const checksumArr_ST = ['J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A']
				const checksumArr_FG = ['X', 'W', 'U', 'T', 'R', 'Q', 'P', 'N', 'M', 'L', 'K']
			    switch (prefix) {
			      case 'S':
			      case 'T':
			        return checksumArr_ST[sum % 11];
			      case 'F':
			      case 'G':
			        return checksumArr_FG[sum % 11];
			      default:
			        throw new Error('Invalid Prefix detected');
			    }
			  },
			save(){
				if(this.finNumber==''||this.mobilePhone==''||this.username==''){
					uni.showToast({
						title:'Please Input',
						icon:'none'
					})
				}else if(!this.fin(this.finNumber)){
					uni.showToast({
						title:'Please enter the correct Fin Number',
						icon:'none'
					})
					
				}else if(this.nationality=='Please Selete Item'){
					uni.showToast({
						title:'Please Choose Nationality',
						icon:'none'
					})
				}else if(isNaN(Number(this.mobilePhone.replace('-','')))){
						uni.showToast({
							title:'Incorrect format of mobile phone number',
							icon:'none'
						})
						return

				}
				else{
					var url 
					if(this.type==1){
						url = 'worker/addWork/'
					}else{
						url = 'worker/updateWork/'
					}
					this.addWork(url)
				}
				
			},
			confirm(e){
				console.log(e[0]['value'])
				this.nationality = e[0]['value']
			},
			async addWork(url){
				var that = this
				var data={
						nationality:this.nationality,
						mobilePhone:this.mobilePhone,
						username:this.username,
						finNumber:this.finNumber,
						subId:app.globalData.subId,
						safetyCardId:this.safetyCardId
					}
				if(url=='worker/updateWork/'){
					data['id']=this.workerId
				}
				const res = await this.$myReuqest({
					url:url,
					method:"POST",
					data:data
				})
				console.log(res)
				if(res.code==200){
					uni.showToast({
						title:res.msg,
						duration:1500
					})
					setTimeout(()=>{
						uni.redirectTo({
							url:"/pages/index/index?index=2"
						})
					},1500)
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			}
		},
	}
</script>

<style>
	.ct-input{
		padding: 30rpx 20rpx;
	}
	.ct-group{
		padding-top: 160rpx;
	}
	.ct-title{
		background-color: rgb(246,246,246);
		height: 80rpx;
		display: flex;
		align-items: center;
		padding-left: 30rpx;
		font-size: 28rpx;
		font-weight: bold;
	}
	.ct-item{
		padding:16rpx 30rpx;
		border-bottom: 1rpx solid  rgb(246,246,246);
	}
	.list-cell {
			font-size: 22rpx;
	        display: flex;
	        box-sizing: border-box;
	        width:100%;
	        padding:20rpx 24rpx;
	        overflow: hidden;
	        color:#323233;
/* 	        line-height:24px; */
	        background-color:#fff;
	}
	.save-pd{
		padding-bottom: 156rpx;
		margin-left: 30rpx;
	}
	.save{
		margin-top: 60rpx;
		width: 260rpx;
		height: 70rpx;
		background: #1890FF;
		border-radius: 5rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.save-img{
		width: 22rpx;
		height: 22rpx;
		margin-right: 10rpx;
	}
	.save-text{
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
	}
	.content{padding:20rpx 30rpx 0 30rpx;display: flex;justify-content: space-between;align-items: center;}
	.back{
		width: 40rpx;
		height: auto;
	}
	.task-group{
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding:190rpx 30rpx 30rpx  30rpx;
	}
	.task-name{
		width: 450rpx;
		font-size: 34rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	page{
		background-color: rgb(243,248,254);
	}
/* 	.line{
		height: 20rpx;
		background-color: rgb(243,248,254);
	} */
	.input-group{
		padding: 42rpx 30rpx;
	}
	.title{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 50rpx;
	}
	.inputName{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		margin-bottom: 16rpx;
	}
	.input-class,.select-items{
		height: 70rpx;
		background: #FFFFFF;
		border: 1px solid #DEDFEC;
		border-radius: 5rpx;
		margin-bottom: 50rpx;
		padding: 0 20rpx;
	}
	.select-items{
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
	.select-img{
		width: 36rpx;
		height: auto;
	}
	.pla-class{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
	}
	.tarea{
		margin-bottom: 50rpx;
		padding: 26rpx 20rpx;
		width: 100%;
		height: 170px;
		background: #FFFFFF;
		border: 1px solid #DEDFEC;
		border-radius: 5px;
	}
	.tip-item{
		display: flex;
		height: 80rpx;
	}
	.tip{
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #E74A3B;
		margin-top: 1rpx;
		padding-bottom: 20rpx;
	}
	.tip-img{
		padding-top: 6rpx;
		width: 36rpx;
		height: auto;
		margin-right: 10rpx;
	}
	.bg-white{
		background-color: #FFFFFF;
	}
</style>
