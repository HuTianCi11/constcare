<template>
	<view class="">
		<view class="back-group">
			<view class="back-item">
				<image src="/static/icon/back.png" mode="widthFix" class="back" @click="back"></image>
				<view class="dispatch">
					<image src="/static/icon/Sign@3x.png" class="nav-img" style="margin-right: 40rpx;" mode="widthFix" @click="edit"></image>
					<image src="/static/icon/delete@3x.png" class="nav-img" mode="widthFix" @click="show=true"></image>
				</view>
			</view>
		</view>
		<u-modal v-model="show" @confirm="delWorkById" confirm-text='Yes' cancel-text='No' title='Tips' content='Confirm to delete?' ref="uModal" ></u-modal>
		<view class="detail-info-group">
			<view class="userName" >{{content.username}}</view>
			<view class="wokrerType" :style="{background:content.type==0?'#FF8D13':'#36B9CC'}">{{content.type==0?'Working':'Resting'}}</view>
			<view class="Information">Information</view>
		</view>
		<view class="group">
			<view class="">
				<view class="items">
					<view class="name">User Name</view>
					<view class="item-text">{{content.username}}</view>
				</view>
				<view class="items">
					<view class="name">Subcontracton</view>
					<view class="item-text">{{content.subId}}</view>
				</view>
				<view class="items">
					<view class="name">Nationality</view>
					<view class="item-text">{{content.nationality}}</view>
				</view>
				<view class="items">
					<view class="name">FIN Numbe</view>
					<view class="item-text">{{content.finNumber}}</view>
				</view>
				<view class="items">
					<view class="name">Mobile Phone Number</view>
					<view class="item-text">{{content.mobilePhone}}</view>
				</view>
				<view class="items">
					<view class="name">Safety Card Id</view>
					<view class="item-text">{{content.safetyCardId}}</view>
				</view>
			</view>
			<view class="Information" style="margin: 40rpx 0 ;" v-if="records.length>0">Task List</view>
		</view>
		<view class="" style="padding-bottom: 160rpx;">
			<view class="task-group" v-for="(item,index) in records">
				<view class="task-top">
					<view class="task-name">
						{{item.taskName}}
					</view>
					<view class="time">
						<view class="day">{{item.day}}<text class="month">/{{item.month}}</text></view>
						<view class="year">{{item.year}}</view>
					</view>
				</view>
				
				<view class="task-content">
					<view class="">
						<view class="SiteName">
							{{item.conName}}
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
	
</template>

<script>
	const app = getApp()
	export default {
		data() {
			return {
				workerId:'',
				content:',',
				current:1,
				show:false,
				records:""
				
			}
		},
		onLoad(opt) {
			this.workerId = opt.id
			this.workerInfo()
			this.workRecord()
		},
		methods: {
			edit(){
				uni.navigateTo({
					url:'./worker-creat?type=2&data='+JSON.stringify(this.content)
				})
			},
			async delWorkById(){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/delWorkById',
					method:"POST",
					data:{
						subId:app.globalData.subId,
						id:this.workerId
					},
					header:{'content-type': 'application/x-www-form-urlencoded'}
				})
				console.log(res)
				
				if(res.code==200){
					uni.showToast({
						title:res.msg,
						duration:1500
					})
					setTimeout(()=>{
						uni.redirectTo({
							url:"/pages/index/index?index=2"
						})
					},1500)
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			async workRecord(){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/workRecord/',
					method:"POST",
					data:{
						current:this.current,
						size : 10,
						subId:app.globalData.subId,
						workId:this.workerId
					},
				})
				console.log(res)
				if(res.code==200){
					for(let i=0;i<res.data.records.length;i++){
						var date = res.data.records[i]['createDate'].split('-')
						res.data.records[i].year = date[0]
						res.data.records[i].month = date[1]
						res.data.records[i].day = date[2]
					}
					this.records = res.data.records
					
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			async workerInfo(){
				var that = this
				const res = await this.$myReuqest({
					url:'worker/workerInfo/',
					method:"POST",
					data:{
						workerId:this.workerId
					},
					header:{'content-type': 'application/x-www-form-urlencoded'}
				})
				console.log(res)
				if(res.code==200){
					this.content = res.data.worker
				}else{
					uni.showToast({
						title:res.msg,
						icon:'none'
					})
				}
			},
			back(){
				uni.navigateBack({
					delta:1
				})
			}
		},
	}
</script>

<style>
	.day{font-size: 30rpx;font-family: PingFang SC;font-weight: 400;color: #232323;}
	.month{font-size: 24rpx;font-family: PingFang SC;font-weight: 400;color: #585B66;}
	.year{font-size: 20rpx;font-family: PingFang SC;font-weight: 400;color: #8B8F9E;text-align: end;}
	.task-top{
		display: flex;
		justify-content: space-between;
	}
	.SiteName{
		font-size: 24rpx;
		font-weight: 400;
		color: #585B66;
		line-height: 33rpx;
		margin-top: 30rpx;
	}
	.task-group{
		margin-bottom: 30rpx;
		background: #F3F8FE;
		padding: 30rpx 30rpx;
	}
	.task-name{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #33343B;
		line-height: 37rpx;
		width: 400rpx;
	}
	.item-text{
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #8B8F9E;
		height: auto;
		white-space:pre-wrap;
		margin-bottom: 40rpx;
		word-break:break-all;
		width: 100%;
	}
	.items{
		display: flex;
		width: 100%;
	}
	.name{
		margin-bottom: 40rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #232323;
		white-space: nowrap;
		width: 600rpx;
	}
	.group{
		padding: 10rpx 30rpx;
	}
	.Information{
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #3E404A;
		padding-bottom: 40rpx;
		background: #FFFFFF;
		border-bottom: 1px solid #DEDFEC;
	}
	.wokrerType{
		margin-top: 30rpx;
		width: 110rpx;
		height: 36rpx;
		background: #FF8D13;
		border-radius: 18rpx;
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 400;
		color: #F8F9FC;
		text-align: center;
		margin-bottom: 78rpx;
	}
	.userName{
		font-size: 36Rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #232323;
	}
	.detail-info-group{
		padding: 190rpx 30rpx 30rpx 30rpx;
	}
	.back-group{
		background-color: #FFFFFF;
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		padding-top: 80rpx;
	}
	.back-item{
		padding: 20rpx  30rpx 20rpx 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		
	}
	.back{
		width: 40rpx;
		height: auto;
	}
	.nav-img{width: 35rpx;}
</style>
