


// var base_Url = 'http://192.168.0.107:8080/'
var base_Url = 'http://constcare.youyongkj.com/'
export const myReuqest = (options)=>{
	return new Promise((resolve,reject)=>{
		if(!options.hidden){
			uni.showLoading({title: 'loading',mask:true});
		}
		uni.request({
			url:base_Url + options.url,
			method:options.method || "GET",
			data:options.data || {},
			header: options.header||{'Content-Type':'application/json'},
			success:(res)=>{
				uni.hideLoading({title:"loading"})
				if(res.data.code==401){
					console.log("登出")
					try {
					    uni.removeStorageSync('loginData');
						console.log("清楚成功")
					} catch (e) {
					    console.log("清楚缓存失败",e)
					}
					setTimeout(()=>{
						uni.redirectTo({
							url:'../login/login'
						})
					},1500)
					
				}
				resolve(res.data)
			},
			fail:(err)=>{
				uni.hideLoading()
				return uni.showToast({
					title:"Network Error",
					icon:'none'
				})
				// console.log(err)
				reject(err)
			}
			
		})
	})
}