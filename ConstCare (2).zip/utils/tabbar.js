var bar=[
	[//main
		{
			"pagePath": "/pages/subcontractor/subcontractor",
			"iconPath": "/static/icon/Sub_nor@2x.png",
			"selectedIconPath": "/static/icon/Sub_sel@2x.png",
			"text": "Subcontractor"
		}, {
			"pagePath": "/pages/task/task",
			"iconPath": "/static/icon/task_nor@2x.png",
			"selectedIconPath": "/static/icon/task_sel@2x.png",
			"text": "Task"
		},
		{
			"pagePath": "/pages/pwt/pwt",
			"iconPath": "/static/icon/pwt_nor@2x.png",
			"selectedIconPath": "/static/icon/pet_sel@2x.png",
			"text": "Pwt"
		},
		{
			"pagePath": "/pages/me/me",
			"iconPath": "/static/icon/me_nor@2x.png",
			"selectedIconPath": "/static/icon/me_sel@2x.png",
			"text": "Me"
		}
	],
	[//sub
		{
			"pagePath": "/pages/task/task",
			"iconPath": "/static/icon/task_nor@2x.png",
			"selectedIconPath": "/static/icon/task_sel@2x.png",
			"text": "Task"
		},
		{
			"pagePath": "/pages/pwt/pwt",
			"iconPath": "/static/icon/pwt_nor@2x.png",
			"selectedIconPath": "/static/icon/pet_sel@2x.png",
			"text": "Pwt"
		},
		{
			"pagePath": "/pages/worker/worker-home",
			"iconPath": "/static/icon/woker_nor@3x.png",
			"selectedIconPath": "/static/icon/woker_sel@3x.png",
			"text": "Worker"
		},
		{
			"pagePath": "/pages/me/me",
			"iconPath": "/static/icon/me_nor@2x.png",
			"selectedIconPath": "/static/icon/me_sel@2x.png",
			"text": "Me"
		}
	],
]
export default{
	bar
}